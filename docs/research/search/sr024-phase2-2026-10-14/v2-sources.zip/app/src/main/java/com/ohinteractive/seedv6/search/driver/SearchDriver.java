package com.ohinteractive.seedv6.search.driver;

import java.util.Objects;

import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.search.common.*;
import com.ohinteractive.seedv6.search.diagnostics.SearchDiagnosticsSnapshot;
import com.ohinteractive.seedv6.search.diagnostics.SearchDiagnosticsSnapshot.IterationMetrics;
import com.ohinteractive.seedv6.search.evaluation.SearchEvaluation;
import com.ohinteractive.seedv6.search.tt.TranspositionScores;
import com.ohinteractive.seedv6.search.tablebase.RootTablebase;

/**
 * R003 production coordinator: depth 1, 2, ...; one full-window ExactSearch
 * invocation at each depth, optionally a drained SR-036 same-depth worker cohort.
 * HCE may use the accepted SR-018/SR-019 selective factory;
 * score provenance survives completed-iteration publication. One R005 TT
 * generation spans all iterations.
 * Worker-confined; separate consumers own separate drivers/evaluator stacks.
 */
public final class SearchDriver implements AutoCloseable {
    private final SingleDepthSearch exact;
    private final RootTablebase tablebase;
    private SearchResult lastCompletedResult;
    private SearchDiagnosticsSnapshot lastDiagnostics = SearchDiagnosticsSnapshot.disabled();
    private boolean active;

    public SearchDriver() { this(SearchEvaluation.handcrafted()); }
    public int activeSearchThreads() { return exact.activeSearchThreads(); }
    public SearchDriver(SearchEvaluation evaluation) { this(ProductionSearch.create(1, evaluation)); }

    /** Compatibility seam for independently supplied single-depth facilities/tests. */
    public SearchDriver(SingleDepthSearch exact) { this(exact, RootTablebase.NONE); }

    /** Explicit managed root-outcome composition; ordinary/training drivers retain their depth contract. */
    public SearchDriver(SingleDepthSearch exact, RootTablebase tablebase) {
        this.exact = Objects.requireNonNull(exact, "exact");
        this.tablebase = Objects.requireNonNull(tablebase, "tablebase");
    }

    public SearchDriverOutcome search(SearchRequest request) {
        var observer = com.ohinteractive.seedv6.search.diagnostics.RootSearchObservation.current();
        if (observer == null) return searchInternal(request);
        long[] board = new long[Board.MAX_BITBOARDS];
        request.copyBoardInto(board);
        var observed = new SearchRequest(board, request.gameHistory(), request.depth(),
                request.observer(), request.control(), true);
        observer.started(observed);
        long started = System.nanoTime();
        var outcome = searchInternal(observed);
        long elapsed = System.nanoTime() - started;
        observer.finished(observed, outcome, elapsed);
        return outcome;
    }

    private SearchDriverOutcome searchInternal(SearchRequest request) {
        Objects.requireNonNull(request, "request");
        if(request.depth() < 1 || request.depth() > maxSupportedDepth())
            throw new IllegalArgumentException("Unsupported iterative depth: " + request.depth());
        if(active) throw new IllegalStateException("SearchDriver cannot be re-entered.");
        active = true;
        lastCompletedResult = null;
        lastDiagnostics = request.diagnosticsEnabled()
                ? SearchDiagnosticsSnapshot.enabledEmpty() : SearchDiagnosticsSnapshot.disabled();
        var workerDiagnostics = lastDiagnostics;
        long nodes = 0;
        int attemptedDepth = 0;
        int completedDepth = 0;
        long aspirationAttempts = 0, failLows = 0, failHighs = 0, fullFallbacks = 0;
        boolean incomplete = false;
        long start = System.nanoTime();
        var control = request.control();
        long[] root = new long[Board.MAX_BITBOARDS];
        request.copyBoardInto(root);
        boolean begun = false;
        try {
            var win = tablebase.probeWin(root, request.gameHistory(), control);
            if(win != null && !Thread.currentThread().isInterrupted()
                    && control.checkpoint() && control.checkpointNodeBudget())
                return new SearchDriverOutcome(null, false, false, 0, false, 0, lastDiagnostics, win);
            exact.beginRequest();
            begun = true;
            for(int depth = 1; depth <= request.depth(); depth++) {
                if(Thread.currentThread().isInterrupted()) control.request(SearchTermination.STOPPED);
                if(Thread.currentThread().isInterrupted() || !control.checkpoint() || !control.checkpointNodeBudget()) break;
                attemptedDepth = depth;
                SearchResult attempt = exact.search(new SearchRequest(root, request.gameHistory(), depth,
                        SearchObserver.NONE, control, request.diagnosticsEnabled()));
                nodes += attempt.nodes();
                if(request.diagnosticsEnabled() && attempt.diagnostics().enabled()) {
                    var metrics = attempt.diagnostics().iteration();
                    aspirationAttempts += metrics.aspirationAttempts();
                    failLows += metrics.failLowResearches();
                    failHighs += metrics.failHighResearches();
                    fullFallbacks += metrics.fullWindowFallbacks();
                    workerDiagnostics = workerDiagnostics.mergeWorkers(
                            attempt.diagnostics().withIteration(IterationMetrics.empty()));
                }
                incomplete = !attempt.completed();
                if(!incomplete) completedDepth = depth;
                if(request.diagnosticsEnabled()) {
                    lastDiagnostics = workerDiagnostics.withIteration(new IterationMetrics(
                            completedDepth, aspirationAttempts, failLows, failHighs, fullFallbacks, completedDepth));
                }
                if(incomplete) break;
                lastCompletedResult = new SearchResult(attempt.bestMove(), attempt.hasMove(), attempt.score(),
                        depth, nodes, attempt.legalRootMoves(), true, attempt.principalVariation(), lastDiagnostics,
                        attempt.selective());
                long elapsed = control.isUnlimited() ? SearchControl.elapsedNanos(System.nanoTime(), start) : control.elapsedNanos();
                request.observer().onIterationCompleted(IterationSnapshot.from(lastCompletedResult, elapsed));
                // At positive depth a completed no-move ExactSearch result is
                // terminal (including rule draws with otherwise legal moves).
                boolean terminal = !attempt.hasMove();
                if(terminal || depth == request.depth())
                    return new SearchDriverOutcome(lastCompletedResult, true, terminal, attemptedDepth, false, nodes, lastDiagnostics);
                // Clock-only decision facts, not a prediction from score/move stability.
                // Keep the actual completed depth; the requested ceiling is not completed.
                if(control.isClockManaged() && (attempt.legalRootMoves() == 1
                        || attempt.score() == TranspositionScores.MATE_SCORE - 1)) {
                    control.completeClockAllocation();
                    break;
                }
            }
            return new SearchDriverOutcome(lastCompletedResult, false, false, attemptedDepth, incomplete, nodes, lastDiagnostics);
        } finally {
            active = false;
            if(begun) exact.endRequest();
        }
    }

    public int maxSupportedDepth() { return exact.maxSupportedDepth(); }
    public SearchResult lastCompletedResult() { return lastCompletedResult; }
    public SearchDiagnosticsSnapshot lastDiagnostics() { return lastDiagnostics; }
    public void newGame() { exact.newGame(); }
    @Override public void close() { exact.close(); }
}
