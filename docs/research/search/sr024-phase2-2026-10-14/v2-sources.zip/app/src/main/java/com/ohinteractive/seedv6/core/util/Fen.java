package com.ohinteractive.seedv6.core.util;

import java.util.Objects;

public class Fen {
    private static final java.util.regex.Pattern FIELD_SEPARATOR = java.util.regex.Pattern.compile("\\s+");

    /** Canonical six-field FEN from the packed Board state, without inventing prior history. */
    public static String fromBoard(long[] board) {
        if (board.length != com.ohinteractive.seedv6.core.Board.MAX_BITBOARDS)
            throw new IllegalArgumentException("Expected complete Board state.");
        StringBuilder fen = new StringBuilder();
        for (int rank = 7; rank >= 0; rank--) {
            int empty = 0;
            for (int file = 0; file < 8; file++) {
                int square = rank * 8 + file;
                int piece = 0;
                for (int plane = 0; plane < 4; plane++) piece |= ((board[plane] >>> square) & 1) << plane;
                if ((piece & 7) == 0) empty++;
                else {
                    if (empty != 0) { fen.append(empty); empty = 0; }
                    fen.append(PIECE_STRING.charAt(piece));
                }
            }
            if (empty != 0) fen.append(empty);
            if (rank != 0) fen.append('/');
        }
        int status = (int) board[com.ohinteractive.seedv6.core.Board.STATUS];
        fen.append((status & 1) == 0 ? " w " : " b ");
        int rights = (status >>> com.ohinteractive.seedv6.core.Board.CASTLING_SHIFT) & 15;
        if (rights == 0) fen.append('-');
        else for (int i = 0; i < 4; i++) if ((rights & (1 << i)) != 0) fen.append(CASTLING_STRING.charAt(i));
        int ep = com.ohinteractive.seedv6.core.Board.enPassantSquare(status);
        fen.append(' ');
        if (ep < 0) fen.append('-');
        else fen.append(FILE_STRING.charAt(ep & 7)).append(1 + (ep >>> 3));
        return fen.append(' ').append(com.ohinteractive.seedv6.core.Board.halfMoveClock(status))
                .append(' ').append(com.ohinteractive.seedv6.core.Board.fullMoveNumber(status)).toString();
    }

    public static int[] getPieces(String fen) {
        return pieces(fields(fen)[0]);
    }

    private static int[] pieces(String fenPieces) {
        final String[] ranks = fenPieces.split("/", -1);
        if(ranks.length != 8) throw invalid("piece placement must contain eight ranks");
        int[] squares = new int[64];
        for(int rankIndex = 0; rankIndex < ranks.length; rankIndex ++) {
            int file = 0;
            for(char c : ranks[rankIndex].toCharArray()) {
                if(c >= '1' && c <= '8') {
                    file += c - '0';
                } else {
                    final int piece = PIECE_STRING.indexOf(c);
                    if(piece <= 0) throw invalid("unknown piece: " + c);
                    if(file >= 8) throw invalid("rank contains more than eight squares");
                    squares[(7 - rankIndex) * 8 + file] = piece;
                    file ++;
                }
                if(file > 8) throw invalid("rank contains more than eight squares");
            }
            if(file != 8) throw invalid("each rank must contain eight squares");
        }
        return squares;
    }

    public static boolean getWhiteToMove(String fen) {
        return whiteToMove(fields(fen)[1]);
    }

    private static boolean whiteToMove(String side) {
        if(!side.equals("w") && !side.equals("b")) throw invalid("side to move must be w or b");
        return side.equals("w");
    }

    public static int getCastling(String fen) {
        return castling(fields(fen)[2]);
    }

    private static int castling(String fenCastlingString) {
        if(fenCastlingString.equals("-")) return 0;
        if(fenCastlingString.isEmpty() || fenCastlingString.length() > 4) {
            throw invalid("invalid castling field");
        }
        int castling = 0;
        for(char c : fenCastlingString.toCharArray()) {
            int castlingCharIndex = CASTLING_STRING.indexOf(c);
            if(castlingCharIndex == -1) throw invalid("invalid castling right: " + c);
            final int right = 1 << castlingCharIndex;
            if((castling & right) != 0) throw invalid("duplicate castling right: " + c);
            castling |= right;
        }
        return castling;
    }

    public static int getEnPassantSquare(String fen) {
        final String enPassant = fields(fen)[3];
        if(enPassant.equals("-")) return -1;
        return enPassant(enPassant, getWhiteToMove(fen));
    }

    private static int enPassant(String enPassant, boolean white) {
        if(enPassant.equals("-")) return -1;
        if(enPassant.length() != 2) throw invalid("invalid en-passant square");
        int file = FILE_STRING.indexOf(enPassant.charAt(0));
        if(file == -1) throw invalid("invalid en-passant file");
        int rank = enPassant.charAt(1) - '1';
        if(rank < 0 || rank > 7) throw invalid("invalid en-passant rank");
        int eSquare = rank << 3 | file;
        int playerToMove = white ? 0 : 1;
        if((playerToMove == 0 && rank != 5) || (playerToMove == 1 && rank != 2)) {
            throw invalid("en-passant rank is inconsistent with side to move");
        }
        return eSquare;
    }

    public static int getHalfMoveClock(String fen) {
        return nonNegativeInteger(fields(fen)[4], "halfmove clock", 0);
    }

    public static int getFullMoveNumber(String fen) {
        return nonNegativeInteger(fields(fen)[5], "fullmove number", 1);
    }

    /** Parse every field once for bulk corpus decoding. Individual accessors retain
     * their existing validation boundaries for engine callers. */
    public record Parsed(int[] pieces, boolean whiteToMove, int castling, int enPassant,
                         int halfmove, int fullmove) {}

    public static Parsed parse(String fen) {
        String[] f = fields(fen);
        boolean white = whiteToMove(f[1]);
        return new Parsed(pieces(f[0]), white, castling(f[2]), enPassant(f[3], white),
                nonNegativeInteger(f[4], "halfmove clock", 0), nonNegativeInteger(f[5], "fullmove number", 1));
    }

    private static final String PIECE_STRING = " KQRBNP  kqrbnp";
    private static final String CASTLING_STRING = "KQkq";
    private static final String FILE_STRING = "abcdefgh";

    private Fen() {}

    private static String[] fields(String fen) {
        final String value = Objects.requireNonNull(fen, "fen").trim();
        final String[] fields = value.isEmpty() ? new String[0] : FIELD_SEPARATOR.split(value);
        if(fields.length != 6) throw invalid("FEN must contain exactly six fields");
        return fields;
    }

    private static int nonNegativeInteger(String value, String name, int minimum) {
        final int parsed;
        try {
            parsed = Integer.parseInt(value);
        } catch(NumberFormatException exception) {
            throw invalid(name + " must be an integer");
        }
        if(parsed < minimum) throw invalid(name + " must be at least " + minimum);
        return parsed;
    }

    private static IllegalArgumentException invalid(String detail) {
        return new IllegalArgumentException("Invalid FEN: " + detail);
    }

}
