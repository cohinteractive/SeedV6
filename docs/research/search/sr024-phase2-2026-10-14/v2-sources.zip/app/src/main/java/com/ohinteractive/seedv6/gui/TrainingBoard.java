package com.ohinteractive.seedv6.gui;

import java.awt.*;
import javax.swing.*;
import com.formdev.flatlaf.util.ScaledImageIcon;
import com.ohinteractive.seedv6.training.service.TrainerSnapshot;
import com.ohinteractive.seedv6.training.telemetry.ActiveGameSnapshot;
import com.ohinteractive.seedv6.core.util.Value;
import com.ohinteractive.seedv6.core.move.Move;
import static com.ohinteractive.seedv6.gui.TrainingDashboard.*;
import static com.ohinteractive.seedv6.gui.TrainingDashboardModel.*;

/** Independent, read-only Training board over immutable move-boundary publications. */
final class TrainingBoard extends JPanel {
    private final JLabel identity = label("Network Training", 17, SeedTheme.TEXT);
    private final JLabel detail = label("No active training game", 12, SeedTheme.SECONDARY);
    private final JLabel sides = label("No active game", 14, SeedTheme.TEXT);
    private final JLabel game = label("Waiting to start", 12, SeedTheme.SECONDARY);
    private final JLabel timer = label("—", 17, SeedTheme.TEXT);
    private final JLabel phase = label("IDLE", 12, SeedTheme.GREEN);
    private final BoardPanel board = new BoardPanel();
    private ActiveGameSnapshot displayed;
    private boolean cleared;
    private final TrainingLoss losses = new TrainingLoss();

    TrainingBoard(Runnable diagnostics) {
        super(new BorderLayout(0, SeedTheme.scale(10))); setOpaque(false);
        JPanel boardCard = new SeedTheme.Card(); boardCard.setLayout(new BorderLayout());
        JPanel top = padded(new BorderLayout(SeedTheme.scale(12), 0), 12);
        top.add(new JLabel(new ScaledImageIcon(new ImageIcon(ApplicationIcons.windowImages().getLast()), 40, 40)), BorderLayout.WEST);
        JPanel names = panel(new GridLayout(2, 1, 0, SeedTheme.scale(5))); identity.setFont(SeedTheme.font(15, Font.BOLD)); identity.setName("trainingBlackIdentity"); names.add(identity); names.add(detail); top.add(names);
        top.add(phase, BorderLayout.EAST); boardCard.add(top, BorderLayout.NORTH);
        board.setName("trainingBoard"); board.setFocusable(false);
        board.showUnavailablePosition("No active training game. Live positions appear during self-play and validation.");
        boardCard.add(board);
        JPanel bottom = padded(new BorderLayout(SeedTheme.scale(10), 0), 10);
        JPanel labels = panel(new GridLayout(2, 1, 0, SeedTheme.scale(5))); labels.add(sides); labels.add(game); bottom.add(labels); bottom.add(timer, BorderLayout.EAST);
        sides.setName("trainingGameSides"); game.setName("trainingGameActivity"); boardCard.add(bottom, BorderLayout.SOUTH); add(boardCard);
        JPanel tools = panel(new BorderLayout(0, SeedTheme.scale(4))); tools.add(timer, BorderLayout.NORTH);
        JButton open = new JButton("Diagnostics"); open.setName("trainingBoardDiagnostics");
        open.addActionListener(e -> diagnostics.run()); tools.add(open); bottom.add(tools, BorderLayout.EAST);
        setMinimumSize(new Dimension(SeedTheme.scale(360), 0));
    }

    void showState(TrainingController.ViewState view) {
        var s = view.loading() ? null : view.snapshot();
        losses.update(view.loading() ? com.ohinteractive.seedv6.training.history.HistoryRepository.Snapshot.EMPTY : view.history());
        var live = view.phase() == TrainingController.Phase.RUNNING && s != null ? s.activeGame().orElse(null) : null;
        phase.setText(phase(view));
        if (live != null) {
            identity.setForeground(BoardPanel.candidateSide(live) == Value.BLACK ? PieceRenderer.CANDIDATE_ACCENT : SeedTheme.TEXT);
            sides.setForeground(BoardPanel.candidateSide(live) == Value.WHITE ? PieceRenderer.CANDIDATE_ACCENT : SeedTheme.TEXT);
            identity.setText("Black: " + participant(live.black()));
            sides.setText("White: " + participant(live.white()));
            identity.setToolTipText(live.black().checkpointId() + " | " + losses.summary(live.black().checkpointId(), s));
            sides.setToolTipText(live.white().checkpointId() + " | " + losses.summary(live.white().checkpointId(), s));
            detail.setText(live.phase() == ActiveGameSnapshot.Phase.SELF_PLAY
                    ? "Self-play · Generation " + live.generation() + " · Game " + live.gameOrdinal() + " / " + view.settings().games()
                    : "Validation · Pair " + ((live.gameOrdinal() + 1) / 2) + " · Game " + live.gameInPair() + " / 2");
            game.setText((live.sideToMove() == Value.WHITE ? "White" : "Black") + " to move · " + live.playedPlies()
                    + " plies" + (live.lastMove() == 0 ? "" : " · Last " + Move.coordinate(live.lastMove())));
            timer.setText(timer(Math.max(0, System.nanoTime() - live.startedNanos()) / 1_000_000_000));
            timer.setToolTipText("Active game elapsed time; not a chess clock");
            if (displayed != live) {
                displayed = live; cleared = false;
                String caption = evaluationCaption(live, view.settings().architecture());
                board.showTrainingPosition(live, score(live, view.settings().architecture()), caption + ". Read-only training position, White at bottom.");
            }
        } else {
            identity.setForeground(SeedTheme.TEXT); sides.setForeground(SeedTheme.TEXT);
            identity.setText(s == null ? "Network Training" : "Training · Generation " + s.generation());
            detail.setText(s == null ? "No network loaded" : "Latest training " + network(s.latestTrainingId()));
            identity.setToolTipText(s == null ? null : s.latestTrainingId() + " | " + losses.summary(s.latestTrainingId(), s)); sides.setToolTipText(null);
            sides.setText("No active game");
            game.setText("Live positions during self-play and validation");
            timer.setText("—"); timer.setToolTipText(null);
            if (!cleared) {
                board.showUnavailablePosition("No active training game. Live positions appear during self-play and validation.");
                displayed = null; cleared = true;
            }
        }
    }

    static String participant(ActiveGameSnapshot.Participant p) { return MatchPresentation.participant(p); }
    static PlayScore score(ActiveGameSnapshot game, NetworkArchitecture architecture) { return MatchPresentation.score(game, architecture); }
    private static String evaluationCaption(ActiveGameSnapshot game, NetworkArchitecture architecture) { return MatchPresentation.evaluationCaption(game, architecture); }

}
