package com.ohinteractive.seedv6.search.common;

import java.util.Objects;

import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.rules.GameHistory;

public final class SearchRequest {

    private final long[] board;
    private final GameHistory gameHistory;
    private final int depth;
    private final SearchObserver observer;
    private final SearchControl control;
    private final boolean diagnosticsEnabled;

    public SearchRequest(long[] board, int depth) {
        this(board, GameHistory.initial(board), depth, SearchObserver.NONE);
    }

    public SearchRequest(long[] board, int depth, SearchObserver observer) {
        this(board, GameHistory.initial(board), depth, observer);
    }

    public SearchRequest(long[] board, GameHistory gameHistory, int depth) {
        this(board, gameHistory, depth, SearchObserver.NONE);
    }

    public SearchRequest(long[] board, GameHistory gameHistory, int depth, SearchObserver observer) {
        this(board, gameHistory, depth, observer, SearchControl.unlimited());
    }

    public SearchRequest(long[] board, GameHistory gameHistory, int depth, SearchControl control) {
        this(board, gameHistory, depth, SearchObserver.NONE, control);
    }

    public SearchRequest(
        long[] board, GameHistory gameHistory, int depth,
        SearchObserver observer, SearchControl control
    ) {
        this(board, gameHistory, depth, observer, control, false);
    }

    public SearchRequest(
        long[] board, GameHistory gameHistory, int depth,
        SearchObserver observer, SearchControl control, boolean diagnosticsEnabled
    ) {
        Objects.requireNonNull(board, "board");
        if(board.length < Board.MAX_BITBOARDS) {
            throw new IllegalArgumentException("Board must contain at least " + Board.MAX_BITBOARDS + " longs.");
        }
        if(depth < 0) {
            throw new IllegalArgumentException("Search depth must not be negative: " + depth);
        }
        this.board = new long[Board.MAX_BITBOARDS];
        System.arraycopy(board, 0, this.board, 0, Board.MAX_BITBOARDS);
        Objects.requireNonNull(gameHistory, "gameHistory").requireCurrent(this.board);
        this.gameHistory = gameHistory.snapshot();
        this.depth = depth;
        this.observer = Objects.requireNonNull(observer, "observer");
        this.control = Objects.requireNonNull(control, "control");
        this.diagnosticsEnabled = diagnosticsEnabled;
    }

    public int depth() {
        return depth;
    }

    public SearchObserver observer() {
        return observer;
    }

    public SearchControl control() {
        return control;
    }

    /** Enables worker-local observational counters without changing search policy. */
    public boolean diagnosticsEnabled() {
        return diagnosticsEnabled;
    }

    /**
     * Immutable, independently owned history whose final entry is this
     * request's root board.
     */
    public GameHistory gameHistory() {
        return gameHistory;
    }

    public void copyBoardInto(long[] destination) {
        Objects.requireNonNull(destination, "destination");
        if(destination.length < Board.MAX_BITBOARDS) {
            throw new IllegalArgumentException("Destination must contain at least " + Board.MAX_BITBOARDS + " longs.");
        }
        System.arraycopy(board, 0, destination, 0, Board.MAX_BITBOARDS);
    }

}
