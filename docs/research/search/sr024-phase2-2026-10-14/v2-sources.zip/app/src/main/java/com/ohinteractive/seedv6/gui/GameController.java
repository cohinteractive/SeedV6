package com.ohinteractive.seedv6.gui;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.nio.file.Path;

import javax.swing.SwingUtilities;

import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.core.move.Move;
import com.ohinteractive.seedv6.core.move.CapturedPieces;
import com.ohinteractive.seedv6.core.move.MoveIntent.Promotion;
import com.ohinteractive.seedv6.core.util.Value;
import com.ohinteractive.seedv6.search.common.IterationSnapshot;
import com.ohinteractive.seedv6.search.common.SearchResult;
import com.ohinteractive.seedv6.search.common.SearchTermination;
import com.ohinteractive.seedv6.search.manage.ManagedSearchResult;
import com.ohinteractive.seedv6.search.manage.SearchLimits;
import com.ohinteractive.seedv6.search.manage.TimeManager;
import com.ohinteractive.seedv6.search.tt.TranspositionScores;
import com.ohinteractive.seedv6.training.checkpoint.CheckpointStore;

/** EDT-confined controller joining Swing interaction to authoritative V6 facilities. */
final class GameController implements BoardPanel.InputListener, SearchGateway.Listener {

    enum GameMode {
        HUMAN_VS_ENGINE("Human vs Engine"),
        ENGINE_VS_ENGINE("Engine vs Engine"),
        HUMAN_VS_HUMAN("Human vs Human");

        private final String label;

        GameMode(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    enum HumanSide {
        WHITE("White", Value.WHITE),
        BLACK("Black", Value.BLACK);

        private final String label;
        private final int player;

        HumanSide(String label, int player) {
            this.label = label;
            this.player = player;
        }

        int player() {
            return player;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    enum LimitKind {
        DEPTH("Depth"),
        MOVETIME("Movetime");

        private final String label;

        LimitKind(String label) {
            this.label = label;
        }

        @Override
        public String toString() {
            return label;
        }
    }

    record SearchSettings(LimitKind kind, int depth, long movetimeMillis) {
        SearchSettings {
            Objects.requireNonNull(kind, "kind");
            if(depth < 1 || depth > 256) {
                throw new IllegalArgumentException("Depth must be in 1..256.");
            }
            if(movetimeMillis < 0L) {
                throw new IllegalArgumentException("Movetime must not be negative.");
            }
        }

        SearchLimits limits() {
            return kind == LimitKind.DEPTH
                ? new SearchLimits(depth, SearchLimits.NO_LIMIT, SearchLimits.NO_LIMIT, false)
                : new SearchLimits(
                    SearchLimits.NO_DEPTH, SearchLimits.NO_LIMIT,
                    TimeManager.movetimeBudgetMillis(movetimeMillis), false
                );
        }
    }

    record PositionView(
        long[] board,
        PositionStatus status,
        List<String> moves,
        int selectedSquare,
        int[] legalTargets,
        int lastFrom,
        int lastTo,
        int checkedKingSquare,
        CapturedPieces captured
    ) {
        PositionView(long[] board, PositionStatus status, List<String> moves, int selectedSquare,
                     int[] legalTargets, int lastFrom, int lastTo, int checkedKingSquare) {
            this(board, status, moves, selectedSquare, legalTargets, lastFrom, lastTo, checkedKingSquare,
                    CapturedPieces.empty(false));
        }
        PositionView {
            board = board.clone();
            moves = List.copyOf(moves);
            legalTargets = legalTargets.clone();
        }

        @Override
        public long[] board() {
            return board.clone();
        }

        @Override
        public int[] legalTargets() {
            return legalTargets.clone();
        }
    }

    record SearchInfo(
        String state,
        int depth,
        String score,
        long nodes,
        long nps,
        String pv,
        String termination,
        long elapsedMillis,
        int scoreSide,
        int activeThreads
    ) {
        SearchInfo(String state, int depth, String score, long nodes, long nps, String pv, String termination,
                   long elapsedMillis, int scoreSide) {
            this(state, depth, score, nodes, nps, pv, termination, elapsedMillis, scoreSide, 0);
        }
        SearchInfo withThreads(int active) {
            return new SearchInfo(state, depth, score, nodes, nps, pv, termination, elapsedMillis, scoreSide, active);
        }
        SearchInfo(String state, int depth, String score, long nodes, long nps, String pv, String termination) {
            this(state, depth, score, nodes, nps, pv, termination, -1, Value.WHITE);
        }
        static SearchInfo idle() {
            return new SearchInfo("Idle", 0, "—", 0L, -1L, "", "—");
        }

        static SearchInfo thinking(int side) {
            return new SearchInfo("Thinking", 0, "—", 0L, -1L, "", "—", -1, side);
        }

        static SearchInfo fromIteration(IterationSnapshot snapshot, int scoreSide) {
            return new SearchInfo(
                "Thinking", snapshot.depth(), formatScore(snapshot.score()),
                snapshot.nodes(), snapshot.nps(), formatPv(snapshot.principalVariation()), "—",
                snapshot.elapsedMillis(), scoreSide
            );
        }

        static SearchInfo fromFinal(ManagedSearchResult result, SearchInfo previous, int scoreSide) {
            if(result.termination() == SearchTermination.BOOK) return new SearchInfo(
                    "Opening book", 0, "—", 0L, -1L, Move.coordinate(result.bestMove()),
                    result.termination().name(), -1L, scoreSide);
            if(result.tablebaseWin() != null) return new SearchInfo(
                    "Tablebase win", 0, "tablebase win", result.nodes(), -1L,
                    Move.coordinate(result.bestMove()), result.termination().name(), -1L, scoreSide);
            final SearchResult completed = result.lastCompletedResult();
            final int depth = completed == null ? previous.depth : completed.depth();
            final String score = completed == null ? previous.score : formatScore(completed.score());
            final String pv = completed == null
                ? previous.pv : formatPv(completed.principalVariation());
            return new SearchInfo(
                result.failure() == null ? "Idle" : "Failed",
                depth, score, result.nodes(), previous.nps, pv,
                result.termination().name(), previous.elapsedMillis, scoreSide
            );
        }

        private static String formatScore(int score) {
            if(!TranspositionScores.isMateScore(score)) return "cp " + score;
            final int pliesToMate = TranspositionScores.MATE_SCORE - Math.abs(score);
            final int movesToMate = (pliesToMate + 1) / 2;
            return "mate " + (score < 0 ? -movesToMate : movesToMate);
        }

        private static String formatPv(long[] moves) {
            final StringBuilder value = new StringBuilder();
            for(long move : moves) {
                if(!value.isEmpty()) value.append(' ');
                value.append(Move.coordinate(move));
            }
            return value.toString();
        }
    }

    interface View {
        void showPosition(PositionView position);
        void showSearch(SearchInfo search);
        void setSearchRunning(boolean running);
        Promotion choosePromotion(List<Promotion> choices);
        void showError(String title, String message);
        default void showEvaluator(PlayEvaluator evaluator, boolean changing) {}
        default void showParticipants(PlayParticipants participants, boolean changing) { showEvaluator(participants.white(), changing); }
        default void showNetworks(CheckpointStore.AvailableCheckpoints available, PlayParticipants.Selection selection, String error) {}
    }

    GameController(SearchGateway search, View view) {
        requireEdt();
        this.search = Objects.requireNonNull(search, "search");
        this.view = Objects.requireNonNull(view, "view");
    }

    void initialize() {
        requireEdt();
        publishPosition();
        view.showSearch(searchInfo);
        view.setSearchRunning(false);
        startEngineIfNeeded();
    }

    void newGame() {
        requireEdt();
        ensureOpen();
        if (evaluatorChanging) return;
        if (search.evaluator().mode() == PlayEvaluator.Mode.BEST_NNUE
                || mode == GameMode.ENGINE_VS_ENGINE && networkSelection.independentStores()) {
            startGame(PlayEvaluator.Mode.BEST_NNUE, mode == GameMode.ENGINE_VS_ENGINE
                    ? networkSelection : search.participants().selection());
            return;
        }
        resetGame();
    }

    /** Capture next-game setup; loading and installation use the same path in both engine modes. */
    void startGame(PlayEvaluator.Mode evaluator, PlayParticipants.Selection selection) {
        requireEdt(); ensureOpen();
        if (evaluatorChanging) return;
        if (evaluator == PlayEvaluator.Mode.HANDCRAFTED && search.participants().white().mode() == evaluator
                && search.participants().black().mode() == evaluator) {
            resetGame(); return;
        }
        changeEvaluator(evaluator, true, true, Objects.requireNonNull(selection));
    }

    void startEngineGame(PlayParticipants.Selection selection) {
        requireEdt(); ensureOpen();
        if (mode != GameMode.ENGINE_VS_ENGINE || evaluatorChanging) return;
        if (!selection.independentStores()
                || selection.whiteMode() != PlayEvaluator.Mode.HANDCRAFTED && selection.whiteRoot() == null
                || selection.blackMode() != PlayEvaluator.Mode.HANDCRAFTED && selection.blackRoot() == null) {
            view.showError("Unable to start game", "Select HCE or a valid checkpoint store for each engine."); return;
        }
        selfPlayContinuous = false;
        networkSelection = selection;
        startGame(PlayEvaluator.Mode.BEST_NNUE, selection);
    }

    private void resetGame() {
        search.invalidate(SearchTermination.NEW_GAME);
        activeToken = null;
        positionRevision ++;
        session = GameSession.startingPosition();
        selfPlayContinuous = mode == GameMode.ENGINE_VS_ENGINE;
        clearSelection();
        searchInfo = SearchInfo.idle();
        publishPosition();
        view.showSearch(searchInfo);
        view.setSearchRunning(false);
        startEngineIfNeeded();
    }

    void setCheckpointRoot(Path root) {
        requireEdt();
        if (checkpointRoot.equals(root)) return;
        checkpointRoot = Objects.requireNonNull(root);
        if (!networkSelection.independentStores()) networkSelection = PlayParticipants.Selection.BEST;
        networkListing++;
        if (networksRequested) {
            view.showNetworks(new CheckpointStore.AvailableCheckpoints(List.of(), List.of()), networkSelection, "");
            refreshNetworks();
        }
    }

    void setNetworkSelection(PlayParticipants.Selection selection) {
        requireEdt(); ensureOpen();
        if (!evaluatorChanging) networkSelection = Objects.requireNonNull(selection);
    }

    PlayParticipants.Selection networkSelection() { requireEdt(); return networkSelection; }

    void refreshNetworks() {
        requireEdt();
        if (closing) return;
        networksRequested = true;
        if (checkpointRoot.equals(listingRoot)) return;
        listingRoot = checkpointRoot;
        long ticket = ++networkListing;
        search.listNetworks(checkpointRoot,
                available -> {
                    if (!closing && ticket == networkListing) {
                        listingRoot = null;
                        view.showNetworks(available, networkSelection, "");
                    }
                }, error -> {
                    if (!closing && ticket == networkListing) {
                        listingRoot = null;
                        view.showNetworks(new CheckpointStore.AvailableCheckpoints(List.of(), List.of()), networkSelection, error);
                    }
                });
    }

    PlayEvaluator evaluator() { requireEdt(); return search.evaluator(); }

    void changeEvaluator(PlayEvaluator.Mode mode, boolean newGame) {
        changeEvaluator(mode, newGame, false);
    }

    private void changeEvaluator(PlayEvaluator.Mode mode, boolean newGame, boolean force) {
        changeEvaluator(mode, newGame, force, this.mode == GameMode.ENGINE_VS_ENGINE
                ? networkSelection : PlayParticipants.Selection.BEST);
    }

    private void changeEvaluator(PlayEvaluator.Mode mode, boolean newGame, boolean force,
                                 PlayParticipants.Selection requested) {
        requireEdt();
        ensureOpen();
        if (evaluatorChanging) return;
        // Re-selecting the current mode must not refresh a running game's pinned Best.
        if (!newGame && !force && mode == search.evaluator().mode()) return;
        evaluatorChanging = true;
        activeToken = null;
        clearSelection();
        view.setSearchRunning(false);
        view.showParticipants(search.participants(), true);
        view.showSearch(new SearchInfo("Loading evaluator", 0, "—", 0, -1, "", "—"));
        try {
            search.changeParticipants(mode, checkpointRoot, requested, error -> {
                if (closing) return;
                evaluatorChanging = false;
                searchInfo = SearchInfo.idle();
                view.showParticipants(search.participants(), false);
                view.showSearch(searchInfo);
                if (error != null) { selfPlayContinuous = false; view.showError("Unable to change evaluator", error); return; }
                if (newGame) resetGame(); else startEngineIfNeeded();
            });
        } catch (RuntimeException failure) {
            evaluatorChanging = false;
            view.showParticipants(search.participants(), false);
            view.showError("Unable to change evaluator", TrainingController.concise(failure));
        }
    }

    boolean loadFen(String fen) {
        requireEdt();
        ensureOpen();
        if (evaluatorChanging) return false;
        final GameSession candidate;
        try {
            candidate = GameSession.fromFen(fen);
        } catch(RuntimeException exception) {
            view.showError("Invalid FEN", exception.getMessage());
            return false;
        }
        search.invalidate(SearchTermination.POSITION_CHANGED);
        activeToken = null;
        positionRevision ++;
        session = candidate;
        clearSelection();
        searchInfo = SearchInfo.idle();
        publishPosition();
        view.showSearch(searchInfo);
        view.setSearchRunning(false);
        startEngineIfNeeded();
        return true;
    }

    void setGameMode(GameMode requestedMode) {
        requireEdt();
        ensureOpen();
        if (evaluatorChanging) return;
        Objects.requireNonNull(requestedMode, "requestedMode");
        if(mode == requestedMode) return;
        search.invalidate(SearchTermination.POSITION_CHANGED);
        activeToken = null;
        boolean leavingSelfPlayNnue = mode == GameMode.ENGINE_VS_ENGINE
                && requestedMode == GameMode.HUMAN_VS_HUMAN
                && search.evaluator().mode() == PlayEvaluator.Mode.BEST_NNUE
                && !search.participants().selection().equals(PlayParticipants.Selection.BEST);
        mode = requestedMode;
        selfPlayContinuous = false;
        clearSelection();
        view.setSearchRunning(false);
        publishPosition();
        if (leavingSelfPlayNnue) {
            changeEvaluator(PlayEvaluator.Mode.BEST_NNUE, false, true);
            return;
        }
        startEngineIfNeeded();
    }

    void setHumanSide(HumanSide requestedSide) {
        requireEdt();
        ensureOpen();
        if (evaluatorChanging) return;
        Objects.requireNonNull(requestedSide, "requestedSide");
        if(humanSide == requestedSide) return;
        search.invalidate(SearchTermination.POSITION_CHANGED);
        activeToken = null;
        humanSide = requestedSide;
        clearSelection();
        view.setSearchRunning(false);
        publishPosition();
        startEngineIfNeeded();
    }

    void setSearchSettings(SearchSettings requestedSettings) {
        requireEdt();
        ensureOpen();
        Objects.requireNonNull(requestedSettings, "requestedSettings");
        if(search.isBusy() || evaluatorChanging) {
            view.showError("Search active", "Search limits can be changed when the current search finishes or is invalidated.");
            return;
        }
        settings = requestedSettings;
    }

    void setWorkerCount(int requestedWorkers) {
        requireEdt();
        ensureOpen();
        if(search.isBusy() || evaluatorChanging) {
            view.showError("Search active", "Threads can be changed when no result is pending.");
            return;
        }
        search.replaceWorkerCount(requestedWorkers);
        searchInfo = SearchInfo.idle();
        view.showSearch(searchInfo);
    }

    int workerCount() {
        requireEdt();
        return search.workerCount();
    }

    void stopSearch() {
        requireEdt();
        ensureOpen();
        if(!search.isSearching()) return;
        if(mode == GameMode.ENGINE_VS_ENGINE) selfPlayContinuous = false;
        search.stop();
        searchInfo = new SearchInfo(
            "Stopping", searchInfo.depth, searchInfo.score, searchInfo.nodes,
            searchInfo.nps, searchInfo.pv, searchInfo.termination, searchInfo.elapsedMillis, searchInfo.scoreSide
        ).withThreads(search.activeSearchThreads());
        view.showSearch(searchInfo);
    }

    boolean canStopGame() {
        requireEdt();
        return !closing && !evaluatorChanging && !session.status().terminal()
                && (mode != GameMode.ENGINE_VS_ENGINE || selfPlayContinuous || search.isSearching()
                    || !session.moveHistory().isEmpty());
    }

    boolean canResign() {
        requireEdt();
        return !closing && !evaluatorChanging && mode == GameMode.HUMAN_VS_ENGINE && !session.status().terminal();
    }

    void stopGame() {
        requireEdt(); ensureOpen();
        if (canStopGame()) terminateGame(PositionStatus.Outcome.STOPPED);
    }

    void resign() {
        requireEdt(); ensureOpen();
        if (canResign()) terminateGame(humanSide.player() == Value.WHITE
                ? PositionStatus.Outcome.WHITE_RESIGNED : PositionStatus.Outcome.BLACK_RESIGNED);
    }

    private void terminateGame(PositionStatus.Outcome outcome) {
        // Suppress delivery immediately; cancellation/draining remains owned by the engine lifecycle.
        activeToken = null;
        positionRevision++;
        selfPlayContinuous = false;
        search.invalidate(SearchTermination.POSITION_CHANGED);
        session.terminate(outcome);
        clearSelection();
        publishPosition();
        view.setSearchRunning(false);
    }

    /** Reuse the shell's existing 500 ms sampler and the same SearchInfo/view publication path. */
    void pollSearchTelemetry() {
        requireEdt();
        if (closing || activeToken == null) return;
        int active = search.activeSearchThreads();
        if (active == searchInfo.activeThreads()) return;
        searchInfo = searchInfo.withThreads(active);
        view.showSearch(searchInfo);
    }

    WorkspaceActivity activity() {
        requireEdt();
        return WorkspaceActivity.play(activeToken != null, searchInfo);
    }

    Runnable beginShutdown() {
        requireEdt();
        if(closing) return search.beginShutdown();
        closing = true;
        activeToken = null;
        clearSelection();
        return search.beginShutdown();
    }

    @Override
    public void squarePressed(int square) {
        requireEdt();
        if(!canHumanMove()) return;
        if(selectedSquare >= 0 && contains(legalTargets, square)) return;
        selectSource(square);
    }

    @Override
    public void squareReleased(int square) {
        requireEdt();
        if(!canHumanMove() || selectedSquare < 0) return;
        if(square == selectedSquare) return;
        if(!contains(legalTargets, square)) {
            selectSource(square);
            return;
        }

        final List<Promotion> promotions = session.promotionChoices(selectedSquare, square);
        final Promotion promotion;
        if(promotions.isEmpty()) {
            promotion = Promotion.NONE;
        } else {
            promotion = view.choosePromotion(promotions);
            if(promotion == null) return;
        }

        try {
            session.applyIntent(selectedSquare, square, promotion);
        } catch(RuntimeException exception) {
            view.showError("Illegal move", exception.getMessage());
            publishPosition();
            return;
        }
        positionRevision ++;
        clearSelection();
        publishPosition();
        startEngineIfNeeded();
    }

    @Override
    public void onIteration(Object uiToken, IterationSnapshot snapshot) {
        requireEdt();
        if(!accepts(uiToken)) return;
        searchInfo = SearchInfo.fromIteration(snapshot, session.status().sideToMove()).withThreads(search.activeSearchThreads());
        view.showSearch(searchInfo);
    }

    @Override
    public void onComplete(Object uiToken, ManagedSearchResult result) {
        requireEdt();
        if(!accepts(uiToken)) return;
        activeToken = null;
        view.setSearchRunning(false);
        searchInfo = SearchInfo.fromFinal(result, searchInfo, session.status().sideToMove());
        view.showSearch(searchInfo);

        if(result.failure() != null || result.termination() == SearchTermination.FAILURE) {
            view.showError("Engine search failed", result.failure() == null
                ? "Search failed." : result.failure().getMessage());
            return;
        }
        if(!result.hasMove()) {
            publishPosition();
            return;
        }
        if(session.status().terminal() || !isEngineControlledSide()) return;
        if(!isApplicableTermination(result.termination())) return;

        try {
            session.applyGeneratedMove(result.bestMove());
        } catch(RuntimeException exception) {
            view.showError("Rejected engine result", exception.getMessage());
            return;
        }
        positionRevision ++;
        clearSelection();
        publishPosition();
        if(result.termination() != SearchTermination.STOPPED) startEngineIfNeeded();
    }

    long[] boardSnapshot() {
        requireEdt();
        return session.boardSnapshot();
    }

    int historySize() {
        requireEdt();
        return session.historySize();
    }

    PositionStatus positionStatus() {
        requireEdt();
        return session.status();
    }

    List<String> displayedMoves() {
        requireEdt();
        return session.moveHistory();
    }

    private final SearchGateway search;
    private final View view;
    private GameSession session = GameSession.startingPosition();
    private GameMode mode = GameMode.HUMAN_VS_ENGINE;
    private HumanSide humanSide = HumanSide.WHITE;
    private SearchSettings settings = new SearchSettings(LimitKind.DEPTH, 4, 1_000L);
    private SearchInfo searchInfo = SearchInfo.idle();
    private Object activeToken;
    private long positionRevision;
    private int selectedSquare = -1;
    private int[] legalTargets = new int[0];
    private boolean selfPlayContinuous;
    private boolean closing;
    private boolean evaluatorChanging;
    private Path checkpointRoot = TrainingSettings.defaultRoot();
    private PlayParticipants.Selection networkSelection = PlayParticipants.Selection.BEST;
    private long networkListing;
    private Path listingRoot;
    private boolean networksRequested;

    private void selectSource(int square) {
        final int[] destinations = session.legalDestinations(square);
        if(destinations.length == 0) {
            clearSelection();
        } else {
            selectedSquare = square;
            legalTargets = destinations;
        }
        publishPosition();
    }

    private void clearSelection() {
        selectedSquare = -1;
        legalTargets = new int[0];
    }

    private void publishPosition() {
        final PositionStatus status = session.status();
        view.showPosition(new PositionView(
            session.boardSnapshot(), status, session.moveHistory(),
            selectedSquare, legalTargets, session.lastFrom(), session.lastTo(),
            status.checkedKingSquare(), session.capturedPieces()
        ));
        if(status.terminal() && !search.isSearching()) {
            searchInfo = new SearchInfo(
                status.outcome() == PositionStatus.Outcome.STOPPED ? "Stopped"
                    : status.outcome() == PositionStatus.Outcome.WHITE_RESIGNED || status.outcome() == PositionStatus.Outcome.BLACK_RESIGNED
                        ? "Resigned" : "Terminal", searchInfo.depth, searchInfo.score, searchInfo.nodes,
                searchInfo.nps, searchInfo.pv, searchInfo.termination, searchInfo.elapsedMillis, searchInfo.scoreSide
            );
            view.showSearch(searchInfo);
        }
    }

    private void startEngineIfNeeded() {
        if(closing || evaluatorChanging || !shouldStartEngine()) return;
        final RequestIdentity token = new RequestIdentity(
            positionRevision, mode, session.status().sideToMove()
        );
        activeToken = token;
        searchInfo = SearchInfo.thinking(session.status().sideToMove());
        view.showSearch(searchInfo);
        view.setSearchRunning(true);
        try {
            search.start(
                session.boardSnapshot(), session.historySnapshot(), settings.limits(),
                token, this
            );
        } catch(RuntimeException exception) {
            activeToken = null;
            view.setSearchRunning(false);
            searchInfo = new SearchInfo("Failed", 0, "—", 0L, -1L, "", "FAILURE");
            view.showSearch(searchInfo);
            view.showError("Unable to start search", exception.getMessage());
        }
    }

    private boolean shouldStartEngine() {
        return !session.status().terminal()
            && !search.isSearching()
            && isEngineControlledSide()
            && (mode != GameMode.ENGINE_VS_ENGINE || selfPlayContinuous);
    }

    private boolean isEngineControlledSide() {
        return switch(mode) {
            case HUMAN_VS_ENGINE -> session.status().sideToMove() != humanSide.player();
            case ENGINE_VS_ENGINE -> true;
            case HUMAN_VS_HUMAN -> false;
        };
    }

    private boolean canHumanMove() {
        if(closing || evaluatorChanging || session.status().terminal() || search.isSearching()) return false;
        return mode == GameMode.HUMAN_VS_HUMAN
            || (mode == GameMode.HUMAN_VS_ENGINE
                && session.status().sideToMove() == humanSide.player());
    }

    private boolean accepts(Object uiToken) {
        if(closing || uiToken == null || uiToken != activeToken) return false;
        final RequestIdentity identity = (RequestIdentity) uiToken;
        return identity.positionRevision == positionRevision
            && identity.mode == mode
            && identity.sideToMove == session.status().sideToMove();
    }

    private void ensureOpen() {
        if(closing) throw new IllegalStateException("Controller is closing.");
    }

    private static boolean isApplicableTermination(SearchTermination termination) {
        return termination == SearchTermination.COMPLETED
            || termination == SearchTermination.TABLEBASE
            || termination == SearchTermination.BOOK
            || termination == SearchTermination.TIME_ALLOCATION
            || termination == SearchTermination.NODE_LIMIT
            || termination == SearchTermination.TIME_LIMIT
            || termination == SearchTermination.STOPPED;
    }

    private static boolean contains(int[] values, int expected) {
        return Arrays.stream(values).anyMatch(value -> value == expected);
    }

    private static void requireEdt() {
        if(!SwingUtilities.isEventDispatchThread()) {
            throw new IllegalStateException("Game controller access must occur on the EDT.");
        }
    }

    private record RequestIdentity(long positionRevision, GameMode mode, int sideToMove) {}
}
