package com.ohinteractive.seedv6.search.exact;

import java.util.Arrays;

/** Optional SR-022 observations, disabled in clean timed runs. Arrays count
 * candidates/omissions, never pretend omitted children were visited/evaluated. */
public class LmpDiagnostics {
    public final long[] eligible = new long[5];
    public final long[] omitted = new long[5];
    public long nonScoutOmissions;
    void reset() { Arrays.fill(eligible, 0); Arrays.fill(omitted, 0); nonScoutOmissions = 0; }
    public void node(long[] board, int ply, int depth) {}
    /** Original invocation window, before any alpha raise or mate-domain tightening. */
    public void node(long[] board, int ply, int depth, int alpha, int beta, boolean explicitScout) {
        node(board, ply, depth);
    }
    /** Exactly the compact searched prefix used by existing history updates. */
    public void cutoff(long[] board, int ply, int depth, long[] searchedMoves, int cutoff) {}
    /** SR-023 read-only observation before a protected-domain quiet candidate is searched or omitted.
     * Frozen evidence is the exact quiet-ordering snapshot; live evidence may include sibling updates.
     * Counts exclude this candidate. Omitted is a decision, never a negative search label. */
    public void historyCandidate(long[] parent, long[] child, long move, int ply, int depth,
            int searched, int searchedQuiets, int alpha, int beta, int frozen, int live, boolean omitted) {}
    /** Read-only reused boards, before evaluator/history preparation; counts are prior searched children. */
    public void omitted(long[] parent, long[] child, long move, int ply, int depth,
            int searched, int searchedQuiets, int alpha, int beta) {}
    /** Read-only reused boards after a completed child; ordinals include this child once. */
    public void searched(long[] parent, long[] child, long move, int ply, int depth,
            int ordinal, int quietOrdinal, int alpha, int beta, int score) {}
}
