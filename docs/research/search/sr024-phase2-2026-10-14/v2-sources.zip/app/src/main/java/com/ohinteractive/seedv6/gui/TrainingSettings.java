package com.ohinteractive.seedv6.gui;

import java.nio.file.Path;
import java.util.Objects;
import java.util.prefs.Preferences;
import com.ohinteractive.seedv6.search.evaluation.NnueScoreMapping;
import com.ohinteractive.seedv6.training.service.TrainerConfig;
import com.ohinteractive.seedv6.training.service.TrainingSource;
import com.ohinteractive.seedv6.training.service.ValidationMethod;
import com.ohinteractive.seedv6.training.service.BrnSupervision;
import com.ohinteractive.seedv6.training.service.BrnCaptureConsistency;
import com.ohinteractive.seedv6.training.service.BrnRunSeeds;
import com.ohinteractive.seedv6.training.service.CorpusTrainingConfig;
import com.ohinteractive.seedv6.training.validation.PromotionPolicy;

/** Convenient UI choices only. Model, Adam and acceptance truth always comes from the store. */
record TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                        int samples, int minibatch, int epochs, int validationPairs, long seed,
                        int maximumPlies, long maximumGenerations, NetworkArchitecture architecture, double brnLearningRate, double brn1LearningRate, double brn2LearningRate, TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency, String corpusRoot, CorpusTrainingConfig corpusTraining, Double recipeLearningRate, long validationMoveMillis, TrainerConfig.SelfPlay generationProtocol) {
    static final NnueScoreMapping SCORE_MAPPING = NnueScoreMapping.V1;

    TrainingSettings {
        Objects.requireNonNull(architecture, "architecture");
        if (validationMoveMillis < 0 || validationMoveMillis > 86_400_000) throw new IllegalArgumentException("Search Time must be 1..86400000 ms, or depth mode.");
        if (maximumRunMinutes < 0 || maximumRunMinutes > 5256000) throw new IllegalArgumentException("Invalid run duration.");
        Objects.requireNonNull(generatorStore, "generatorStore");
        Objects.requireNonNull(corpusRoot, "corpusRoot");
        if (corpusTraining != null) corpusTraining = corpusTraining.forArchitecture(architecture.trainingArchitecture());
        if (teacherStore != null) teacherStore = teacherStore.isBlank() ? "" : Path.of(teacherStore).toAbsolutePath().normalize().toString();
        if (runSeeds != null && (architecture != NetworkArchitecture.BRN2 || seed != runSeeds.masterSeed()))
            throw new IllegalArgumentException("Run seeds require BRN-2 and matching master seed.");
        if (supervision != null) supervision.requireSupported(architecture.trainingArchitecture(), source);
        if (captureConsistency != null) captureConsistency.requireSupported(architecture.trainingArchitecture(), supervision, source);
        new com.ohinteractive.seedv6.core.brn.BrnAdamConfig(brnLearningRate);
        new com.ohinteractive.seedv6.core.brn.BrnAdamConfig(brn1LearningRate);
        new com.ohinteractive.seedv6.core.brn.BrnAdamConfig(brn2LearningRate);
        if (recipeLearningRate != null) new com.ohinteractive.seedv6.core.brn.BrnAdamConfig(recipeLearningRate);
        root = root.toAbsolutePath().normalize();
        // Use the authoritative service configuration validation, including cross-field bounds.
        config(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, TrainerConfig.DepthChange.REQUIRE_SAME, architecture, architecture == NetworkArchitecture.BRN_PAIR2 ? .01 : architecture == NetworkArchitecture.BRN3 ? .003 : architecture == NetworkArchitecture.BRN2 ? brn2LearningRate : architecture == NetworkArchitecture.BRN1 ? brn1LearningRate : brnLearningRate);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency,
            String corpusRoot, CorpusTrainingConfig corpusTraining, Double recipeLearningRate, long validationMoveMillis) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency,
                corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, null);
    }
    TrainingSettings withGenerationProtocol(TrainerConfig.SelfPlay protocol) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes,
                validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, protocol);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency,
            String corpusRoot, CorpusTrainingConfig corpusTraining, Double recipeLearningRate) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency,
                corpusRoot, corpusTraining, recipeLearningRate, 0);
    }
    TrainingSettings withValidationMoveTime(long millis) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes,
                validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, millis, generationProtocol);
    }

    // Absence is deliberate: old configurations continue their exact stored optimizer rate.
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency,
            String corpusRoot, CorpusTrainingConfig corpusTraining) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency, corpusRoot, corpusTraining, null);
    }
    double initialLearningRate() {
        return switch (architecture) {
            case NNUE, NNUE_MATERIAL -> .001;
            case BRN3 -> .003;
            case BRN_PAIR2 -> .01;
            case BRN -> brnLearningRate;
            case BRN1 -> brn1LearningRate;
            case BRN2 -> brn2LearningRate;
        };
    }
    TrainingSettings withLearningRate(Double rate) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes,
                validationMethod, captureConsistency, corpusRoot, corpusTraining, rate, validationMoveMillis, generationProtocol);
    }
    com.ohinteractive.seedv6.training.model.TrainingRecipe recipe() {
        return new com.ohinteractive.seedv6.training.model.TrainingRecipe(recipeLearningRate == null ? initialLearningRate() : recipeLearningRate,
                architecture.usesMinibatches() ? minibatch : 1, architecture.usesMinibatches() ? epochs : 1);
    }

    // Legacy GUI callers and saved configurations have no corpus fields.
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency,
                source != null && source.corpus() ? source.generatorStore() : "", null);
    }

    TrainingSettings withCorpus(String path, CorpusTrainingConfig value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes,
                validationMethod, captureConsistency, path, value, recipeLearningRate, validationMoveMillis, generationProtocol);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs, seed,
                maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, null);
    }
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMinutes, ValidationMethod validationMethod) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs, seed,
                maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, null);
    }
    TrainingSettings withCaptureConsistency(BrnCaptureConsistency value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, value, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }
    TrainingSettings withValidationMethod(ValidationMethod value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes, value, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }
    ValidationMethod selectedValidation() {
        return generatedValidation();
    }
    ValidationMethod generatedValidation() {
        return validationMethod == null ? source == null && !architecture.nnueFamily()
                ? ValidationMethod.HELD_OUT : ValidationMethod.legacy(source) : validationMethod;
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double rate, double rate1, double rate2,
            TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs, seed,
                maximumPlies, maximumGenerations, architecture, rate, rate1, rate2, source, generatorStore,
                supervision, runSeeds, teacherStore, 0);
    }
    TrainingSettings withTimeLimit(long minutes) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, teacherStore, minutes, validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
            int samples, int minibatch, int epochs, int validationPairs, long seed, int maximumPlies,
            long maximumGenerations, NetworkArchitecture architecture, double brnLearningRate, double brn1LearningRate,
            double brn2LearningRate, TrainingSource source, String generatorStore, BrnSupervision supervision, BrnRunSeeds runSeeds) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, null);
    }
    TrainingSettings withTeacherStore(String value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, runSeeds, value, maximumRunMinutes, validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture,
                     double brnLearningRate, double brn1LearningRate, double brn2LearningRate,
                     TrainingSource source, String generatorStore) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, null);
    }
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture,
                     double brnLearningRate, double brn1LearningRate, double brn2LearningRate,
                     TrainingSource source, String generatorStore, BrnSupervision supervision) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, supervision, null);
    }
    TrainingSettings withRunSeeds(BrnRunSeeds value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, value == null ? seed : value.masterSeed(), maximumPlies, maximumGenerations, architecture,
                brnLearningRate, brn1LearningRate, brn2LearningRate, source, generatorStore, supervision, value, teacherStore, maximumRunMinutes, validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }
    TrainingSettings withSupervision(BrnSupervision value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, source, generatorStore, value, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency, corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture,
                     double brnLearningRate, double brn1LearningRate, double brn2LearningRate) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate, brn2LearningRate, null, "");
    }
    TrainingSettings withSource(TrainingSource value) {
        return new TrainingSettings(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate,
                brn2LearningRate, value, value != null && value.nnue() ? value.generatorStore() : generatorStore, supervision, runSeeds, teacherStore, maximumRunMinutes, validationMethod, captureConsistency, value != null && value.corpus() ? value.generatorStore() : corpusRoot, corpusTraining, recipeLearningRate, validationMoveMillis, generationProtocol);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture, double brnLearningRate, double brn1LearningRate) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, brn1LearningRate, TrainerConfig.DEFAULT_BRN_LEARNING_RATE);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture, double brnLearningRate) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, brnLearningRate, TrainerConfig.DEFAULT_BRN_LEARNING_RATE);
    }

    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations, NetworkArchitecture architecture) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs, validationPairs,
                seed, maximumPlies, maximumGenerations, architecture, TrainerConfig.DEFAULT_BRN_LEARNING_RATE);
    }

    // Existing callers continue to default to NNUE.
    TrainingSettings(Path root, int depth, int threads, int games, int openingMin, int openingMax,
                     int samples, int minibatch, int epochs, int validationPairs, long seed,
                     int maximumPlies, long maximumGenerations) {
        this(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, NetworkArchitecture.NNUE);
    }

    static Path defaultRoot() {
        return defaultRoot(System.getenv("LOCALAPPDATA"), System.getProperty("user.home"));
    }

    static Path defaultRoot(String localAppData, String userHome) {
        return localAppData == null || localAppData.isBlank()
                ? Path.of(userHome, ".seedv6-nnue", "training")
                : Path.of(localAppData, "SeedV6-NNUE", "training");
    }

    static TrainingSettings defaults() {
        return new TrainingSettings(defaultRoot(), 4, 1, 64, 0, 8, 32, 32, 1, 64, 1L, 1024, 0);
    }

    static TrainingSettings defaults(Path root, NetworkArchitecture architecture) {
        var d = defaults();
        var result = new TrainingSettings(root, d.depth, d.threads, d.games, d.openingMin, d.openingMax,
                d.samples, architecture.corpusOnly() ? 128 : d.minibatch,
                architecture.corpusOnly() ? 8 : d.epochs, d.validationPairs,
                d.seed, d.maximumPlies, d.maximumGenerations, architecture);
        return architecture.corpusOnly() ? result.withSource(TrainingSource.dataSources(
                com.ohinteractive.seedv6.training.data.DataSources.directory(root)))
                .withCorpus("", new CorpusTrainingConfig(131072, "").forArchitecture(architecture.trainingArchitecture()))
                .withValidationMethod(ValidationMethod.HELD_OUT) : result;
    }

    boolean corpusSelected() { return source != null && source.corpus(); }
    com.ohinteractive.seedv6.training.service.RunTermination termination() {
        return new com.ohinteractive.seedv6.training.service.RunTermination(maximumGenerations,
                java.time.Duration.ofMinutes(maximumRunMinutes).toMillis());
    }

    TrainerConfig config(TrainerConfig.DepthChange depthChange) {
        return config(root, depth, threads, games, openingMin, openingMax, samples, minibatch, epochs,
                validationPairs, seed, maximumPlies, maximumGenerations, depthChange, architecture, architecture == NetworkArchitecture.BRN_PAIR2 ? .01 : architecture == NetworkArchitecture.BRN3 ? .003 : architecture == NetworkArchitecture.BRN2 ? brn2LearningRate : architecture == NetworkArchitecture.BRN1 ? brn1LearningRate : brnLearningRate)
                .withSource(source).withRunSeeds(runSeeds)
                .withSupervision(corpusSelected() ? BrnSupervision.WDL : supervision)
                .withTeacherStore(corpusSelected() ? null : teacherStore)
                .withTimeLimit(java.time.Duration.ofMinutes(maximumRunMinutes))
                .withValidationMethod(validationMethod)
                .withCaptureConsistency(corpusSelected() ? BrnCaptureConsistency.OFF : captureConsistency)
                .withCorpusTraining(corpusSelected() ? corpusTraining : null)
                .withLearningRate(recipeLearningRate).withValidationMoveTime(validationMoveMillis).withGenerationProtocol(generationProtocol);
    }

    private static TrainerConfig config(Path root, int depth, int threads, int games, int openingMin,
            int openingMax, int samples, int minibatch, int epochs, int pairs, long seed, int maxPlies,
            long maxGenerations, TrainerConfig.DepthChange change, NetworkArchitecture architecture, double brnLearningRate) {
        threads = new com.ohinteractive.seedv6.search.exact.SearchThreads(threads).resolve();
        return new TrainerConfig(root, seed,
                new TrainerConfig.SelfPlay(depth, threads, games, openingMin, openingMax, samples, maxPlies, SCORE_MAPPING),
                new TrainerConfig.Training(architecture.usesMinibatches() ? epochs : 1,
                        architecture.usesMinibatches() ? minibatch : 1, true),
                new TrainerConfig.Validation(pairs, openingMin, openingMax, depth, threads, maxPlies,
                        SCORE_MAPPING, new PromotionPolicy(pairs, PromotionPolicy.DEFAULT.alpha(),
                                PromotionPolicy.DEFAULT.requiredMargin())), maxGenerations, change, TrainerConfig.STANDARD_START,
                architecture.trainingArchitecture(), brnLearningRate);
    }

    static Preferences preferences() { return Preferences.userNodeForPackage(TrainingSettings.class).node("nnue-training"); }

    /** Startup needs only machine-local selection. Configuration is loaded from the selected lineage. */
    static TrainingSettings selectionDefaults(Preferences prefs) {
        TrainingFolders.migrate(prefs);
        try {
            // A historical root without an explicit selection still belongs to legacy NNUE.
            String fallback = prefs.get(TrainingFolders.key(NetworkArchitecture.NNUE), "").isBlank()
                    ? NetworkArchitecture.NNUE_MATERIAL.name() : NetworkArchitecture.NNUE.name();
            var architecture = NetworkArchitecture.valueOf(prefs.get("architecture", fallback));
            String selected = prefs.get(TrainingFolders.key(architecture), "");
            return defaults(selected.isBlank() ? defaultRoot() : Path.of(selected), architecture);
        } catch (RuntimeException invalidSelection) { return defaults(); }
    }

    static TrainingSettings load(Preferences prefs) {
        TrainingSettings d = defaults();
        TrainingFolders.migrate(prefs);
        try {
            var architecture = NetworkArchitecture.valueOf(prefs.get("architecture", NetworkArchitecture.NNUE.name()));
            String selected = prefs.get(TrainingFolders.key(architecture), "");
            // Settings require a valid path; the GUI separately displays an unset selection and blocks Start.
            return new TrainingSettings(selected.isBlank() ? d.root : Path.of(selected),
                    prefs.getInt("depth", d.depth), prefs.getInt("threads", d.threads), prefs.getInt("games", d.games),
                    prefs.getInt("openingMin", d.openingMin), prefs.getInt("openingMax", d.openingMax),
                    prefs.getInt("samples", d.samples), prefs.getInt("minibatch", d.minibatch),
                    prefs.getInt("epochs", d.epochs), prefs.getInt("validationPairs", d.validationPairs),
                    prefs.getLong("seed", d.seed), prefs.getInt("maximumPlies", d.maximumPlies),
                    prefs.getLong("maximumGenerations", d.maximumGenerations),
                    architecture,
                    prefs.getDouble("brnLearningRate", d.brnLearningRate),
                    prefs.getDouble("brn1LearningRate", d.brn1LearningRate),
                    prefs.getDouble("brn2LearningRate", d.brn2LearningRate), sourcePreference(prefs, architecture, selected),
                    prefs.get("nnueGeneratorStore." + architecture.name(), "")).withSupervision(supervisionPreference(prefs, architecture, selected))
                    .withRunSeeds(runSeedsPreference(prefs, architecture, selected))
                    .withCaptureConsistency(architecture == NetworkArchitecture.BRN2 && !selected.isBlank()
                            && selected.equals(prefs.get("brn2Capture.root", "")) && prefs.get("brn2Capture.lambda", null) != null
                            ? new BrnCaptureConsistency(prefs.getDouble("brn2Capture.lambda", 0)) : null)
                    .withTeacherStore(architecture == NetworkArchitecture.BRN2 && selected.equals(prefs.get("brn2Teacher.root", ""))
                            ? prefs.get("brn2Teacher.store", null) : null).withTimeLimit(prefs.getLong("maximumRunMinutes", 0))
                    .withValidationMethod(prefs.get("validationMethod", "").isEmpty() ? null : ValidationMethod.valueOf(prefs.get("validationMethod", "")))
                    .withCorpus(architecture.supportsTrainingData() && selected.equals(prefs.get(corpusPreferencePrefix(architecture) + "root", ""))
                            ? prefs.get(corpusPreferencePrefix(architecture) + "path", "") : "",
                            architecture.supportsTrainingData() && selected.equals(prefs.get(corpusPreferencePrefix(architecture) + "root", ""))
                            && prefs.get(corpusPreferencePrefix(architecture) + "positions", null) != null
                            ? new CorpusTrainingConfig(prefs.getInt(corpusPreferencePrefix(architecture) + "positions", 2), prefs.get(corpusPreferencePrefix(architecture) + "identity", ""), prefs.get(corpusPreferencePrefix(architecture) + "adapter", "")) : null)
                    .withLearningRate(selected.equals(prefs.get("recipeRate." + architecture.name() + ".root", ""))
                            && prefs.get("recipeRate." + architecture.name() + ".rate", null) != null
                            ? prefs.getDouble("recipeRate." + architecture.name() + ".rate", .001) : null)
                    .withValidationMoveTime(selected.equals(prefs.get("validationSearch." + architecture.name() + ".root", ""))
                            ? prefs.getLong("validationSearch." + architecture.name() + ".millis", 0) : 0)
                    .withGenerationProtocol(generationPreference(prefs, architecture, selected));
        } catch (RuntimeException invalidPreference) { return d; }
    }

    private static TrainerConfig.SelfPlay generationPreference(Preferences prefs, NetworkArchitecture architecture, String root) {
        String prefix = "generationProtocol." + architecture.name() + ".";
        if (!root.equals(prefs.get(prefix + "root", "")) || prefs.get(prefix + "depth", null) == null) return null;
        return new TrainerConfig.SelfPlay(prefs.getInt(prefix + "depth", 4), prefs.getInt(prefix + "threads", 1),
                prefs.getInt(prefix + "games", 64), prefs.getInt(prefix + "min", 0), prefs.getInt(prefix + "max", 8),
                prefs.getInt(prefix + "samples", 32), prefs.getInt(prefix + "cap", 1024),
                new NnueScoreMapping(prefs.getDouble(prefix + "scale", SCORE_MAPPING.scale())));
    }

    void save(Preferences prefs) {
        save(prefs, true);
    }

    private static String corpusPreferencePrefix(NetworkArchitecture architecture) { return architecture == NetworkArchitecture.BRN_PAIR2 ? "brnPair2Corpus." : architecture == NetworkArchitecture.BRN3 ? "brn3Corpus." : architecture == NetworkArchitecture.NNUE_MATERIAL ? "nnueMaterialCorpus." : architecture == NetworkArchitecture.NNUE ? "nnueCorpus." : "brn2Corpus."; }

    private static TrainingSource sourcePreference(Preferences prefs, NetworkArchitecture architecture, String root) {
        String prefix = "trainingSource." + architecture.name() + ".";
        if (root.isBlank() || !root.equals(prefs.get(prefix + "root", ""))) return null;
        String mode = prefs.get(prefix + "mode", "");
        return mode.isBlank() ? null : new TrainingSource(TrainingSource.Mode.valueOf(mode), prefs.get(prefix + "generator", ""));
    }

    private static BrnSupervision supervisionPreference(Preferences prefs, NetworkArchitecture architecture, String root) {
        if (architecture != NetworkArchitecture.BRN2 || root.isBlank()
                || !root.equals(prefs.get("brn2Supervision.root", ""))) return null;
        String mode = prefs.get("brn2Supervision.mode", "");
        return mode.isEmpty() ? null : new BrnSupervision(BrnSupervision.Mode.valueOf(mode), prefs.getDouble("brn2Supervision.weight", 0));
    }

    private static BrnRunSeeds runSeedsPreference(Preferences prefs, NetworkArchitecture architecture, String root) {
        if (architecture != NetworkArchitecture.BRN2 || root.isBlank()
                || !root.equals(prefs.get("brn2RunSeeds.root", "")) || prefs.get("brn2RunSeeds.data", "").isEmpty()) return null;
        return new BrnRunSeeds(prefs.getLong("brn2RunSeeds.master", 1), Long.parseLong(prefs.get("brn2RunSeeds.data", "")));
    }

    // The production panel persists selection immediately; queued configuration saves must not
    // overwrite a later architecture/folder selection made while the I/O executor was busy.
    void saveConfiguration(Preferences prefs) { save(prefs, false); }

    private void save(Preferences prefs, boolean selection) {
        TrainingFolders.migrate(prefs);
        String validationPrefix = "validationSearch." + architecture.name() + ".";
        prefs.put(validationPrefix + "root", root.toString()); prefs.putLong(validationPrefix + "millis", validationMoveMillis);
        String generatedPrefix = "generationProtocol." + architecture.name() + ".";
        prefs.put(generatedPrefix + "root", root.toString());
        if (generationProtocol == null) prefs.remove(generatedPrefix + "depth");
        else {
            var g = generationProtocol;
            prefs.putInt(generatedPrefix + "depth", g.depth()); prefs.putInt(generatedPrefix + "threads", g.threads());
            prefs.putInt(generatedPrefix + "games", g.games()); prefs.putInt(generatedPrefix + "min", g.minimumOpeningPlies());
            prefs.putInt(generatedPrefix + "max", g.maximumOpeningPlies()); prefs.putInt(generatedPrefix + "samples", g.maximumSamplesPerGame());
            prefs.putInt(generatedPrefix + "cap", g.maximumPlies()); prefs.putDouble(generatedPrefix + "scale", g.scoreMapping().scale());
        }
        String ratePrefix = "recipeRate." + architecture.name() + ".";
        prefs.put(ratePrefix + "root", root.toString());
        if (recipeLearningRate == null) prefs.remove(ratePrefix + "rate"); else prefs.putDouble(ratePrefix + "rate", recipeLearningRate);
        if (validationMethod != null) prefs.put("validationMethod", validationMethod.name());
        if (architecture.supportsTrainingData()) {
            String prefix = corpusPreferencePrefix(architecture);
            prefs.put(prefix + "root", root.toString()); prefs.put(prefix + "path", corpusRoot);
            if (corpusTraining == null) { prefs.remove(prefix + "positions"); prefs.remove(prefix + "identity"); prefs.remove(prefix + "adapter"); }
            else { prefs.putInt(prefix + "positions", corpusTraining.positionsPerGeneration()); prefs.put(prefix + "identity", corpusTraining.viewIdentity()); prefs.put(prefix + "adapter", corpusTraining.targetAdapter()); }
        }
        if (architecture == NetworkArchitecture.BRN2) {
            prefs.put("brn2Capture.root", root.toString());
            if (captureConsistency == null) prefs.remove("brn2Capture.lambda");
            else prefs.putDouble("brn2Capture.lambda", captureConsistency.lambda());
            prefs.put("brn2Teacher.root", root.toString());
            if (teacherStore == null) prefs.remove("brn2Teacher.store"); else prefs.put("brn2Teacher.store", teacherStore);
            prefs.put("brn2RunSeeds.root", root.toString());
            prefs.put("brn2RunSeeds.data", runSeeds == null ? "" : Long.toString(runSeeds.dataSeed()));
            if (runSeeds != null) prefs.putLong("brn2RunSeeds.master", runSeeds.masterSeed());
        }
        if (architecture == NetworkArchitecture.BRN2 && supervision != null) {
            prefs.put("brn2Supervision.root", root.toString()); prefs.put("brn2Supervision.mode", supervision.mode().name());
            prefs.putDouble("brn2Supervision.weight", supervision.teacherWeight());
        }
        if (!architecture.nnueFamily()) prefs.put("nnueGeneratorStore." + architecture.name(), generatorStore);
        if (source != null) {
            String prefix = "trainingSource." + architecture.name() + ".";
            prefs.put(prefix + "root", root.toString()); prefs.put(prefix + "mode", source.mode().name());
            prefs.put(prefix + "generator", source.generatorStore());
        }
        // Absence remains the historical NNUE default; retain every existing NNUE key/value.
        if (selection) prefs.put("architecture", architecture.name());
        if (brnLearningRate != TrainerConfig.DEFAULT_BRN_LEARNING_RATE || architecture == NetworkArchitecture.BRN
                || prefs.get("brnLearningRate", null) != null) prefs.putDouble("brnLearningRate", brnLearningRate);
        if (brn1LearningRate != TrainerConfig.DEFAULT_BRN_LEARNING_RATE || architecture == NetworkArchitecture.BRN1
                || prefs.get("brn1LearningRate", null) != null) prefs.putDouble("brn1LearningRate", brn1LearningRate);
        if (brn2LearningRate != TrainerConfig.DEFAULT_BRN_LEARNING_RATE || architecture == NetworkArchitecture.BRN2
                || prefs.get("brn2LearningRate", null) != null) prefs.putDouble("brn2LearningRate", brn2LearningRate);
        if (selection) prefs.put(TrainingFolders.key(architecture), root.toString());
        prefs.putInt("depth", depth); prefs.putInt("threads", threads);
        prefs.putInt("games", games); prefs.putInt("openingMin", openingMin); prefs.putInt("openingMax", openingMax);
        prefs.putInt("samples", samples); prefs.putInt("minibatch", minibatch); prefs.putInt("epochs", epochs);
        prefs.putInt("validationPairs", validationPairs); prefs.putLong("seed", seed);
        prefs.putInt("maximumPlies", maximumPlies); prefs.putLong("maximumGenerations", maximumGenerations); prefs.putLong("maximumRunMinutes", maximumRunMinutes);
    }
}
