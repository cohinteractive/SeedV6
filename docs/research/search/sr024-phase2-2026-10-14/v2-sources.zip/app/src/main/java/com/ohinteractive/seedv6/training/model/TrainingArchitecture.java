package com.ohinteractive.seedv6.training.model;

import java.io.IOException;
import com.ohinteractive.seedv6.core.brn1.Brn1Codec;
import com.ohinteractive.seedv6.core.brn2.Brn2Codec;
import com.ohinteractive.seedv6.core.brn2.Brn2Features;
import com.ohinteractive.seedv6.core.brn.BrnCodec;
import com.ohinteractive.seedv6.core.brn.BrnFeatureSchema;
import com.ohinteractive.seedv6.core.nnue.NnueFeatureSchema;
import com.ohinteractive.seedv6.core.nnue.NnueNetworkCodec;
import com.ohinteractive.seedv6.training.nnue.TrainingStateCodec;

/** Closed set of implemented training payloads. Existing NNUE wire identity stays unchanged. */
public enum TrainingArchitecture {
    NNUE(NnueFeatureSchema.ID, NnueFeatureSchema.VERSION, "network.nnue",
            NnueNetworkCodec.ENCODED_BYTES, TrainingStateCodec.ENCODED_BYTES),
    NNUE_MATERIAL("seedv6.nnue.halfkp.material-additive.v1", 1, "network.nnue-material",
            NnueNetworkCodec.ENCODED_BYTES, TrainingStateCodec.ENCODED_BYTES),
    BRN("seedv6.brn.0", BrnFeatureSchema.VERSION, "network.brn", BrnCodec.MODEL_BYTES, BrnCodec.TRAINING_BYTES),
    BRN1("seedv6.brn.1", BrnFeatureSchema.VERSION, "network.brn1", Brn1Codec.MODEL_BYTES, Brn1Codec.TRAINING_BYTES),
    BRN2("seedv6.brn.2", Brn2Features.VERSION, "network.brn2", Brn2Codec.MODEL_BYTES, Brn2Codec.TRAINING_BYTES),
    BRN3("seedv6.brn.3", com.ohinteractive.seedv6.core.brn3.Brn3Layout.VERSION, "network.brn3",
            com.ohinteractive.seedv6.core.brn3.Brn3Codec.MODEL_BYTES, com.ohinteractive.seedv6.core.brn3.Brn3Codec.TRAINING_BYTES),
    // Legacy wire/file identity of BRE-Pair 2. Campaign bindings and checkpoints depend on it.
    BRN_PAIR2("seedv6.brn.pair2", 1, "network.brn-pair2",
            com.ohinteractive.seedv6.core.brnpair2.BrnPair2Codec.MODEL_BYTES, com.ohinteractive.seedv6.core.brnpair2.BrnPair2Codec.TRAINING_BYTES);

    private final String schemaId, networkFile;
    private final int schemaVersion;
    private final long networkBytes, trainingBytes;

    TrainingArchitecture(String schemaId, int schemaVersion, String networkFile, long networkBytes, long trainingBytes) {
        this.schemaId = schemaId; this.schemaVersion = schemaVersion; this.networkFile = networkFile;
        this.networkBytes = networkBytes; this.trainingBytes = trainingBytes;
    }
    public boolean corpusOnly() { return this == BRN3 || this == BRN_PAIR2; }
    public boolean nnueFamily() { return this == NNUE || this == NNUE_MATERIAL; }
    /** Existing managed-library layout; independent of translated/display labels. */
    public String folderName() {
        return this == BRN_PAIR2 ? "BRN-Pair2" : this == NNUE ? "NNUE" : this == NNUE_MATERIAL ? "NNUE-Material"
                : this == BRN ? "BRN-0" : name().replace("BRN", "BRN-");
    }
    /** Keep enum toString/name stable: old campaign bindings contain them. */
    public String displayName() {
        return this == BRN_PAIR2 ? "BRE-Pair 2" : this == NNUE ? "NNUE (legacy, no material)" : this == NNUE_MATERIAL ? "NNUE (material parity)"
                : this == BRN ? "BRN-0" : name().replace("BRN", "BRN-");
    }
    public String schemaId() { return schemaId; }
    public int schemaVersion() { return schemaVersion; }
    public String networkFile() { return networkFile; }
    public long networkBytes() { return networkBytes; }
    public long trainingBytes() { return trainingBytes; }

    public static TrainingArchitecture fromSchema(String id, int version) throws IOException {
        if (BRN2.schemaId.equals(id) && version == 1) throw new IncompatibleEncodingException();
        for (var architecture : values()) {
            if (architecture.schemaId.equals(id) && architecture.schemaVersion == version) return architecture;
        }
        throw new IOException("Incompatible checkpoint architecture/schema: " + id + " / " + version);
    }

    /** A recognized incompatible encoding is not a corrupt sibling to skip during recovery. */
    public static final class IncompatibleEncodingException extends IOException {
        public IncompatibleEncodingException() { super(Brn2Features.LEGACY_MESSAGE); }
    }
}
