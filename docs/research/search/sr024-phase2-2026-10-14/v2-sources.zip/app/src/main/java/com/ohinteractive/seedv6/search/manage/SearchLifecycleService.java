package com.ohinteractive.seedv6.search.manage;

import java.util.Objects;
import java.util.SplittableRandom;
import java.util.random.RandomGenerator;
import java.util.function.Supplier;

import com.ohinteractive.seedv6.book.Book;
import com.ohinteractive.seedv6.rules.DrawAdjudicator;

import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.core.Gen;
import com.ohinteractive.seedv6.search.evaluation.SearchEvaluation;
import com.ohinteractive.seedv6.rules.GameHistory;
import com.ohinteractive.seedv6.search.common.IterationSnapshot;
import com.ohinteractive.seedv6.search.common.SearchControl;
import com.ohinteractive.seedv6.search.common.SearchObserver;
import com.ohinteractive.seedv6.search.common.SearchRequest;
import com.ohinteractive.seedv6.search.common.SearchResult;
import com.ohinteractive.seedv6.search.common.SearchTermination;
import com.ohinteractive.seedv6.search.common.SingleDepthSearch;
import com.ohinteractive.seedv6.search.common.TimeSource;
import com.ohinteractive.seedv6.search.diagnostics.SearchDiagnosticsSnapshot;
import com.ohinteractive.seedv6.search.driver.ProductionSearch;
import com.ohinteractive.seedv6.search.driver.ExactSearchAdapter;
import com.ohinteractive.seedv6.search.driver.SearchDriver;
import com.ohinteractive.seedv6.search.driver.SearchDriverOutcome;
import com.ohinteractive.seedv6.search.tablebase.RootTablebase;
import com.ohinteractive.seedv6.search.tablebase.SyzygyNative;

/**
 * Single owner of managed search generations, cancellation, the reusable
 * worker-confined search instance, publication, stale suppression and shutdown.
 */
public final class SearchLifecycleService implements AutoCloseable {

    @FunctionalInterface
    public interface Listener {
        void onSearchComplete(ManagedSearchResult result);
    }

    public SearchLifecycleService() {
        this(TimeSource.SYSTEM, ExactSearchAdapter::new, SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    /** One owner plus, when requested, private recursive helper workers. */
    public SearchLifecycleService(int rootWorkers) {
        this(rootWorkers, SearchEvaluation.handcrafted());
    }

    /** Explicit fixed-evaluator selection; ordinary GUI/UCI startup remains handcrafted. */
    public SearchLifecycleService(int rootWorkers, SearchEvaluation evaluation) {
        this(TimeSource.SYSTEM, () -> ProductionSearch.create(rootWorkers, evaluation),
                SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    /** Explicit static-leaf control with the same optional book/tablebase facilities as production. */
    public static SearchLifecycleService staticControl(int rootWorkers, SearchEvaluation evaluation) {
        return new SearchLifecycleService(TimeSource.SYSTEM,
                () -> ProductionSearch.createStaticControl(rootWorkers, evaluation),
                SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    /** Pre-SR-005 control with the same optional book/tablebase facilities as production. */
    public static SearchLifecycleService iterationReuseControl(int rootWorkers, SearchEvaluation evaluation) {
        return new SearchLifecycleService(TimeSource.SYSTEM,
                () -> ProductionSearch.createIterationReuseControl(rootWorkers, evaluation),
                SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    /** SR-029 control with the same optional book/tablebase facilities as production. */
    public static SearchLifecycleService quietLmrControl(int rootWorkers, SearchEvaluation evaluation) {
        return new SearchLifecycleService(TimeSource.SYSTEM,
                () -> ProductionSearch.createQuietLmrControl(rootWorkers, evaluation),
                SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    /** SR-001 control with the same optional book/tablebase facilities as production. */
    public static SearchLifecycleService unprunedControl(int rootWorkers, SearchEvaluation evaluation) {
        return new SearchLifecycleService(TimeSource.SYSTEM,
                () -> ProductionSearch.createUnprunedControl(rootWorkers, evaluation),
                SyzygyNative.configured(), Book.bundled(), new SplittableRandom());
    }

    public SearchLifecycleService(
        TimeSource timeSource, Supplier<? extends SingleDepthSearch> searchFactory
    ) {
        this(timeSource, searchFactory, RootTablebase.NONE);
    }

    public SearchLifecycleService(TimeSource timeSource, Supplier<? extends SingleDepthSearch> searchFactory,
            RootTablebase tablebase) {
        // Explicit search facilities keep their search-only contract.
        this(timeSource, searchFactory, tablebase, Book.EMPTY, new SplittableRandom());
    }

    SearchLifecycleService(TimeSource timeSource, Supplier<? extends SingleDepthSearch> searchFactory,
            RootTablebase tablebase, Book book, RandomGenerator random) {
        this.book = Objects.requireNonNull(book, "book");
        this.random = Objects.requireNonNull(random, "random");
        this.timeSource = Objects.requireNonNull(timeSource, "timeSource");
        search = new SearchDriver(
            Objects.requireNonNull(searchFactory, "searchFactory").get(), tablebase
        );
        worker = new Thread(this::workerLoop, "seedv6-search-worker");
        worker.start();
    }

    public long start(
        long[] board, GameHistory history, SearchLimits limits, Listener listener
    ) {
        return start(board, history, limits, SearchObserver.NONE, listener);
    }

    public long start(
        long[] board, GameHistory history, SearchLimits limits,
        SearchObserver observer, Listener listener
    ) {
        return start(board, history, limits, observer, false, listener);
    }

    /** Starts one managed generation with optional worker-local diagnostics. */
    public long start(
        long[] board, GameHistory history, SearchLimits limits,
        SearchObserver observer, boolean diagnosticsEnabled, Listener listener
    ) {
        Objects.requireNonNull(board, "board");
        Objects.requireNonNull(history, "history");
        Objects.requireNonNull(limits, "limits");
        Objects.requireNonNull(observer, "observer");
        Objects.requireNonNull(listener, "listener");
        if(limits.depth() > search.maxSupportedDepth()) {
            throw new IllegalArgumentException("Unsupported search depth: " + limits.depth());
        }

        final long[] boardSnapshot = new long[Board.MAX_BITBOARDS];
        System.arraycopy(board, 0, boardSnapshot, 0, Board.MAX_BITBOARDS);
        history.requireCurrent(boardSnapshot);
        final GameHistory historySnapshot = history.snapshot();
        final long startNanos = timeSource.nanoTime();
        final long timeBudgetNanos = limits.timeMillis() == SearchLimits.NO_LIMIT
            ? SearchLimits.NO_LIMIT
            : TimeManager.millisToNanos(limits.timeMillis());
        final SearchControl control = SearchControl.controlled(
            limits.nodes(), startNanos, timeBudgetNanos, timeSource, limits.clockManaged()
        );

        synchronized(lock) {
            ensureOpen();
            generation ++;
            if(current != null) current.control.request(SearchTermination.REPLACED);
            if(pending != null) pending.control.request(SearchTermination.REPLACED);
            final SearchJob job = new SearchJob(
                generation, boardSnapshot, historySnapshot, limits, control,
                startNanos, observer, diagnosticsEnabled, bookEnabled, listener
            );
            current = job;
            pending = job;
            lock.notifyAll();
            return generation;
        }
    }

    /** Applies to subsequent generations; an active request keeps its original policy. */
    public void setBookEnabled(boolean enabled) {
        synchronized(lock) { ensureOpen(); bookEnabled = enabled; }
    }

    public void stop() {
        synchronized(lock) {
            if(current != null) current.control.request(SearchTermination.STOPPED);
        }
    }

    public void invalidate(SearchTermination reason) {
        if(reason != SearchTermination.POSITION_CHANGED && reason != SearchTermination.NEW_GAME) {
            throw new IllegalArgumentException("Unsupported invalidation reason: " + reason);
        }
        synchronized(lock) {
            generation ++;
            if(current != null) current.control.request(reason);
            if(pending != null) pending.control.request(reason);
            if(reason == SearchTermination.NEW_GAME) newGamePending = true;
            current = null;
            pending = null;
            lock.notifyAll();
        }
    }

    public boolean isSearching() {
        synchronized(lock) {
            return current != null;
        }
    }

    /** Generation-bound live participants; replacement/invalidation cannot expose draining old workers. */
    public int activeSearchThreads(long expectedGeneration) {
        synchronized(lock) {
            return !shutdown && current != null && current == executingJob
                    && current.generation == expectedGeneration ? search.activeSearchThreads() : 0;
        }
    }

    /** Includes an invalidated job still draining on the worker, for exclusive GUI workloads. */
    public boolean isWorking() {
        synchronized(lock) {
            return current != null || pending != null || executing;
        }
    }

    public long generation() {
        synchronized(lock) {
            return generation;
        }
    }

    public Throwable lastFailure() {
        return lastFailure;
    }

    public boolean isTerminated() {
        return !worker.isAlive();
    }

    @Override
    public void close() {
        synchronized(lock) {
            if(!shutdown) {
                shutdown = true;
                generation ++;
                if(current != null) current.control.request(SearchTermination.SHUTDOWN);
                if(pending != null) pending.control.request(SearchTermination.SHUTDOWN);
                current = null;
                pending = null;
                lock.notifyAll();
            }
        }
        // A listener may close its own lifecycle. The owner exits after the callback.
        if(Thread.currentThread() == worker) return;
        joinWorker();
        if(worker.isAlive()) {
            worker.interrupt();
            joinWorker();
        }
        // Cleanup runs on the owner, but callers still need its failure outcome.
        Throwable failure = closeFailure;
        if(failure instanceof RuntimeException runtime) throw runtime;
        if(failure instanceof Error error) throw error;
        if(failure != null) throw new IllegalStateException("Search resource cleanup failed.", failure);
    }

    private static final int MAX_MOVES = 256;
    private static final long JOIN_MILLIS = 2_000L;

    private final Object lock = new Object();
    private final TimeSource timeSource;
    private final SearchDriver search;
    private final Book book;
    private final RandomGenerator random; // Only the lifecycle worker consumes it.
    private boolean bookEnabled = true;
    private final Thread worker;
    private long generation;
    private SearchJob current;
    private SearchJob pending;
    private boolean shutdown;
    private boolean executing;
    private SearchJob executingJob;
    // Reset on the owner thread, after old work drains and before the next request.
    private boolean newGamePending;
    private volatile Throwable lastFailure;
    private volatile Throwable closeFailure;

    private void workerLoop() {
        try {
            serveJobs();
        } finally {
            // A bounded caller join may time out while a dependency is still running.
            // Only this owner can know that Search and all its helpers have drained.
            try {
                search.close();
            } catch(Throwable failure) {
                closeFailure = failure;
                lastFailure = failure;
            }
        }
    }

    private void serveJobs() {
        while(true) {
            final SearchJob job;
            final boolean reset;
            synchronized(lock) {
                while(pending == null && !shutdown) {
                    try {
                        lock.wait();
                    } catch(InterruptedException exception) {
                        if(shutdown) return;
                    }
                }
                if(shutdown) return;
                job = pending;
                pending = null;
                reset = newGamePending;
                newGamePending = false;
                executing = true;
                executingJob = job;
            }

            final ManagedSearchResult result = execute(job, reset);
            synchronized(lock) {
                executing = false;
                executingJob = null;
                if(current != job || shutdown) continue;
                ManagedSearchResult publication = result;
                final SearchTermination controlReason = job.control.termination();
                if((controlReason == SearchTermination.STOPPED
                        || controlReason == SearchTermination.NODE_LIMIT
                        || controlReason == SearchTermination.TIME_LIMIT)
                    && (publication.termination() == SearchTermination.COMPLETED
                        || publication.termination() == SearchTermination.TABLEBASE
                        || publication.termination() == SearchTermination.BOOK)) {
                    // Preserve a proof completed before the stop, and the actual recorded reason.
                    publication = publication.withTermination(controlReason);
                }
                current = null;
                try {
                    job.listener.onSearchComplete(publication);
                } catch(Throwable failure) {
                    lastFailure = failure;
                }
            }
        }
    }

    private ManagedSearchResult execute(SearchJob job, boolean reset) {
        if(reset) {
            try {
                search.newGame();
            } catch(Throwable failure) {
                // Do not run a new request with a reset that failed; retry on the next one.
                synchronized(lock) { newGamePending = true; }
                return failure(job, null, failure, job.diagnosticsEnabled
                        ? SearchDiagnosticsSnapshot.enabledEmpty() : SearchDiagnosticsSnapshot.disabled());
            }
        }
        final long[] rootMoves = new long[MAX_MOVES];
        final long[] scratch = new long[Board.MAX_BITBOARDS];
        final int rootMoveCount;
        try {
            rootMoveCount = Gen.genAll(
                job.board[0], job.board[1], job.board[2], job.board[3],
                (int) job.board[Board.STATUS], job.board[Board.KEY], true, rootMoves, scratch
            );
        } catch(Throwable failure) {
            return failure(
                job, null, failure,
                job.diagnosticsEnabled
                    ? SearchDiagnosticsSnapshot.enabledEmpty()
                    : SearchDiagnosticsSnapshot.disabled()
            );
        }

        final boolean hasLegalMoves = rootMoveCount > 0;
        SearchResult lastCompleted = null;
        SearchDiagnosticsSnapshot diagnostics = job.diagnosticsEnabled
            ? SearchDiagnosticsSnapshot.enabledEmpty()
            : SearchDiagnosticsSnapshot.disabled();
        boolean searchStarted = false;
        try {
            // Book is a play decision, with no searched depth/score. Infinite analysis,
            // terminal/rule-draw roots and already-cancelled work retain search semantics.
            if (job.bookEnabled && !job.limits.infinite() && hasLegalMoves
                    && job.control.termination() == SearchTermination.NONE
                    && !DrawAdjudicator.isFiftyMoveClaimable((int) job.board[Board.STATUS])
                    && !job.history.isFormalThreefold(job.board)) {
                long move = book.choose(job.board, rootMoves, rootMoveCount, random);
                if (move != 0L)
                    return managed(job, null, SearchTermination.BOOK, move, true, null, diagnostics);
            }
            final int maximumDepth = job.limits.depth() == SearchLimits.NO_DEPTH
                ? search.maxSupportedDepth()
                : job.limits.depth();
            // A terminal root is exact independently of an already-expired go
            // budget. Its separate unlimited traversal has no child nodes but
            // retains the managed monotonic start for reporting.
            final SearchControl iterationControl = hasLegalMoves ? job.control
                : SearchControl.controlled(
                    SearchLimits.NO_LIMIT, job.startNanos, SearchLimits.NO_LIMIT,
                    timeSource
                );
            searchStarted = true;
            final SearchDriverOutcome outcome = search.search(
                new SearchRequest(
                    job.board, job.history, hasLegalMoves ? maximumDepth : 1,
                    iterationObserver(job), iterationControl, job.diagnosticsEnabled
                )
            );
            lastCompleted = outcome.lastCompletedResult();
            diagnostics = outcome.diagnostics();
            if(outcome.tablebaseWin() != null) {
                // UCI infinite analysis still owns the lifecycle until an external stop/invalidation.
                if(job.limits.infinite()) iterationControl.awaitTermination();
                return new ManagedSearchResult(job.generation, outcome.tablebaseWin().bestMove(), true,
                        null, SearchTermination.TABLEBASE, job.control.nodes(), null, diagnostics, outcome.tablebaseWin());
            }
            if(outcome.targetDepthCompleted()) {
                return managed(
                    job, lastCompleted, SearchTermination.COMPLETED,
                    lastCompleted.bestMove(), lastCompleted.hasMove(), null, diagnostics
                );
            }

            return interrupted(job, lastCompleted, diagnostics);
        } catch(Throwable failure) {
            if(searchStarted) {
                if(lastCompleted == null) lastCompleted = search.lastCompletedResult();
                diagnostics = search.lastDiagnostics();
            }
            return failure(job, lastCompleted, failure, diagnostics);
        }
    }

    private ManagedSearchResult interrupted(
        SearchJob job, SearchResult lastCompleted, SearchDiagnosticsSnapshot diagnostics
    ) {
        final SearchTermination reason = job.control.termination() == SearchTermination.NONE
            ? SearchTermination.FAILURE
            : job.control.termination();
        final boolean useCompleted = lastCompleted != null && lastCompleted.hasMove();
        return managed(
            job, lastCompleted, reason,
            useCompleted ? lastCompleted.bestMove() : 0L,
            useCompleted, null, diagnostics
        );
    }

    private ManagedSearchResult failure(
        SearchJob job, SearchResult lastCompleted,
        Throwable failure, SearchDiagnosticsSnapshot diagnostics
    ) {
        lastFailure = failure;
        final boolean useCompleted = lastCompleted != null && lastCompleted.hasMove();
        return managed(
            job, lastCompleted, SearchTermination.FAILURE,
            useCompleted ? lastCompleted.bestMove() : 0L,
            useCompleted,
            failure, diagnostics
        );
    }

    private ManagedSearchResult managed(
        SearchJob job, SearchResult completed, SearchTermination reason,
        long bestMove, boolean hasMove, Throwable failure,
        SearchDiagnosticsSnapshot diagnostics
    ) {
        return new ManagedSearchResult(
            job.generation, hasMove ? bestMove : 0L, hasMove, completed,
            reason, job.control.nodes(), failure, diagnostics
        );
    }

    /**
     * Iteration callbacks run synchronously on the owned worker while holding
     * the generation gate. Replacement/invalidation therefore cannot race an
     * old callback past the installation of a newer generation. Observer
     * failures are recorded and contained; exact search ownership continues.
     */
    private SearchObserver iterationObserver(SearchJob job) {
        return new SearchObserver() {
            @Override
            public void onIterationCompleted(IterationSnapshot snapshot) {
                synchronized(lock) {
                    if(current != job || shutdown) return;
                    try {
                        job.observer.onIterationCompleted(snapshot);
                    } catch(Throwable failure) {
                        lastFailure = failure;
                    }
                }
            }
        };
    }

    private void ensureOpen() {
        if(shutdown) throw new IllegalStateException("Search lifecycle is shut down.");
    }

    private void joinWorker() {
        boolean interrupted = false;
        try {
            worker.join(JOIN_MILLIS);
        } catch(InterruptedException exception) {
            interrupted = true;
        }
        if(interrupted) Thread.currentThread().interrupt();
    }

    private static final class SearchJob {
        final long generation;
        final long[] board;
        final GameHistory history;
        final SearchLimits limits;
        final SearchControl control;
        final long startNanos;
        final SearchObserver observer;
        final boolean diagnosticsEnabled;
        final boolean bookEnabled;
        final Listener listener;

        SearchJob(
            long generation, long[] board, GameHistory history, SearchLimits limits,
            SearchControl control, long startNanos, SearchObserver observer,
            boolean diagnosticsEnabled, boolean bookEnabled, Listener listener
        ) {
            this.generation = generation;
            this.board = board;
            this.history = history;
            this.limits = limits;
            this.control = control;
            this.startNanos = startNanos;
            this.observer = observer;
            this.diagnosticsEnabled = diagnosticsEnabled;
            this.bookEnabled = bookEnabled;
            this.listener = listener;
        }
    }
}
