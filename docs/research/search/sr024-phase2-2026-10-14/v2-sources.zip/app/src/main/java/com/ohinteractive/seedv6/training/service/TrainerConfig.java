package com.ohinteractive.seedv6.training.service;

import java.nio.file.Path;
import com.ohinteractive.seedv6.training.model.TrainingArchitecture;
import com.ohinteractive.seedv6.core.brn.BrnAdamConfig;
import java.util.Objects;
import java.util.SplittableRandom;
import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.search.evaluation.NnueScoreMapping;
import com.ohinteractive.seedv6.training.selfplay.SelfPlayConfig;
import com.ohinteractive.seedv6.training.selfplay.SelfPlayTraining;
import com.ohinteractive.seedv6.training.validation.PromotionPolicy;
import com.ohinteractive.seedv6.training.validation.ValidationConfig;

/**
 * Fixed for one service instance. Zero maximumGenerations means indefinite; a positive bound counts
 * newly trained generations in this run, excluding startup reconciliation. Resume may explicitly
 * select another depth, but never rewrites old manifests. All other settings are explicit caller
 * choices too; an already recorded validation is always completed under its stored policy.
 * Unfinished work records its effective settings. Changed settings restart from its settled parent;
 * unchanged settings preserve exact continuation. Legacy ordinary Candidates predate this record
 * and expose only their stored depth/source for comparison. startingFen defaults to normal chess; an explicit legal fixture is useful
 * for bounded experiments. Codecs enforce the accepted V1 model/optimizer schema on every load.
 */
public record TrainerConfig(Path checkpointRoot, long masterSeed, SelfPlay selfPlay, Training training,
                            Validation validation, long maximumGenerations, DepthChange depthChange,
                            String startingFen, TrainingArchitecture architecture, double brnLearningRate,
                            TrainingSource source, BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore, long maximumRunMillis,
                            String frozenReplayHash, ValidationMethod validationMethod, BrnCaptureConsistency captureConsistency,
                            CorpusTrainingConfig corpusTraining) {
    public static final double DEFAULT_BRN_LEARNING_RATE = 0.001;
    public static final String STANDARD_START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
    public enum DepthChange { REQUIRE_SAME, EXPLICITLY_ALLOW }
    public enum SeedDomain {
        SELF_PLAY(0x6A09E667F3BCC909L), SHUFFLE(0xBB67AE8584CAA73BL), VALIDATION(0x3C6EF372FE94F82BL),
        HOLDOUT(0xA54FF53A5F1D36F1L), CAPTURE(0x510E527FADE682D1L);
        private final long salt;
        SeedDomain(long salt) { this.salt = salt; }
    }

    public TrainerConfig {
        checkpointRoot = Objects.requireNonNull(checkpointRoot, "checkpointRoot").toAbsolutePath().normalize();
        Objects.requireNonNull(selfPlay); Objects.requireNonNull(training);
        Objects.requireNonNull(validation); Objects.requireNonNull(depthChange);
        Objects.requireNonNull(startingFen); Objects.requireNonNull(architecture);
        Objects.requireNonNull(frozenReplayHash);
        if (!frozenReplayHash.isEmpty() && !frozenReplayHash.matches("[0-9a-f]{64}"))
            throw new IllegalArgumentException("Invalid frozen replay identity.");
        new BrnAdamConfig(brnLearningRate);
        if (teacherStore != null) teacherStore = teacherStore.isBlank() ? "" : Path.of(teacherStore).toAbsolutePath().normalize().toString();
        if (source != null && (source.mode() == TrainingSource.Mode.HANDCRAFTED || source.frozen()) && architecture != TrainingArchitecture.BRN2)
            throw new IllegalArgumentException("Handcrafted generation or frozen replay requires BRN-2.");
        if (runSeeds != null && (architecture != TrainingArchitecture.BRN2 || masterSeed != runSeeds.masterSeed()))
            throw new IllegalArgumentException("Persisted run seeds require BRN-2 and matching master seed.");
        if (supervision != null) supervision.requireSupported(architecture, source);
        if (corpusTraining != null && (architecture != TrainingArchitecture.BRN2 && !architecture.nnueFamily() && !architecture.corpusOnly() || source != null && !source.corpus()))
            throw new IllegalArgumentException("Corpus training requires an external NNUE, BRN-2, BRN-3 or BRE-Pair 2 source.");
        if (corpusTraining != null) corpusTraining = corpusTraining.forArchitecture(architecture);
        if (source != null && source.corpus() && (architecture != TrainingArchitecture.BRN2 && !architecture.nnueFamily() && !architecture.corpusOnly()
                || supervision != null && supervision.blended() || captureConsistency != null && captureConsistency.enabled()))
            throw new IllegalArgumentException("Corpus training requires NNUE, BRN-2, BRN-3 or BRE-Pair 2 and no blended supervision/capture.");
        if(architecture.corpusOnly() && source!=null && !source.corpus())throw new IllegalArgumentException("This architecture trains from Training Data.");
        if (captureConsistency != null) captureConsistency.requireSupported(architecture, supervision, source);
        if (architecture.nnueFamily() && source != null && source.bootstrap() && !source.corpus())
            throw new IllegalArgumentException("NNUE training does not support BRN bootstrap mode.");
        if (!architecture.nnueFamily() && !architecture.corpusOnly() && (training.epochs() != 1 || training.minibatchSize() != 1))
            throw new IllegalArgumentException("BRN requires one online pass per generation.");
        if (maximumRunMillis < 0) throw new IllegalArgumentException("Negative time limit.");
        if (maximumGenerations < 0) throw new IllegalArgumentException("Negative generation limit.");
        if (architecture != TrainingArchitecture.NNUE
                && (!NnueScoreMapping.V1.equals(selfPlay.scoreMapping()) || !NnueScoreMapping.V1.equals(validation.scoreMapping())))
            throw new IllegalArgumentException("BRN uses fixed full-range search units for self-play and validation.");
        Board.fromFen(startingFen);
    }

    /** Original canonical signature remains source-compatible for every existing caller. */
    public TrainerConfig(Path checkpointRoot, long masterSeed, SelfPlay selfPlay, Training training, Validation validation,
            long maximumGenerations, DepthChange depthChange, String startingFen, TrainingArchitecture architecture,
            double brnLearningRate, TrainingSource source, BrnSupervision supervision, BrnRunSeeds runSeeds,
            String teacherStore, long maximumRunMillis, String frozenReplayHash, ValidationMethod validationMethod,
            BrnCaptureConsistency captureConsistency) {
        this(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, brnLearningRate, source, supervision, runSeeds, teacherStore, maximumRunMillis,
                frozenReplayHash, validationMethod, captureConsistency, null);
    }
    public TrainerConfig withCorpusTraining(CorpusTrainingConfig value) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, value);
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double rate, TrainingSource source,
                         BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore, long maximumRunMillis,
                         String frozenReplayHash) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, rate, source, supervision, runSeeds, teacherStore, maximumRunMillis, frozenReplayHash, null);
    }
    /** Null restores the durable BRN-2 selection; missing legacy state resolves to OFF. */
    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double rate, TrainingSource source,
                         BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore, long maximumRunMillis,
                         String frozenReplayHash, ValidationMethod validationMethod) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, rate, source, supervision, runSeeds, teacherStore, maximumRunMillis, frozenReplayHash,
                validationMethod, null);
    }
    public BrnCaptureConsistency effectiveCaptureConsistency() {
        return captureConsistency == null ? BrnCaptureConsistency.OFF : captureConsistency;
    }
    public TrainerConfig withCaptureConsistency(BrnCaptureConsistency value) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, frozenReplayHash, validationMethod, value, corpusTraining);
    }
    public TrainerConfig withValidationMethod(ValidationMethod method) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, frozenReplayHash, method, captureConsistency, corpusTraining);
    }
    public ValidationMethod validationMethod(TrainingSource selected) {
        return validationMethod == null ? ValidationMethod.legacy(selected) : validationMethod;
    }
    public boolean heldOut(TrainingSource selected) { return validationMethod(selected) == ValidationMethod.HELD_OUT; }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double rate, TrainingSource source,
                         BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore, long maximumRunMillis) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, rate, source, supervision, runSeeds, teacherStore, maximumRunMillis, "");
    }
    public TrainerConfig withFrozenReplayHash(String hash) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, hash, validationMethod, captureConsistency, corpusTraining);
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double rate, TrainingSource source,
                         BrnSupervision supervision, BrnRunSeeds runSeeds, String teacherStore) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, rate, source, supervision, runSeeds, teacherStore, 0);
    }
    public TrainerConfig withTimeLimit(java.time.Duration duration) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore, duration.toMillis(), frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }
    public TrainerConfig withGenerationProtocol(SelfPlay protocol) {
        if (protocol == null) return this;
        return new TrainerConfig(checkpointRoot, masterSeed, protocol, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }
    public TrainerConfig withValidationMoveTime(long millis) {
        var v = validation;
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training,
                new Validation(v.openingPairs(), v.minimumOpeningPlies(), v.maximumOpeningPlies(), v.depth(),
                        v.threads(), v.maximumPlies(), v.scoreMapping(), v.policy(), millis), maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, teacherStore,
                maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }
    public RunTermination termination() { return new RunTermination(maximumGenerations, maximumRunMillis); }
    /** Null preserves the stored optimizer's rate, including old caller/configuration behavior. */
    public TrainerConfig withLearningRate(Double rate) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay,
                new Training(training.epochs(), training.minibatchSize(), training.shuffle(), rate), validation,
                maximumGenerations, depthChange, startingFen, architecture, brnLearningRate, source, supervision,
                runSeeds, teacherStore, maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }
    public long finalGeneration(long settledGeneration) {
        if (settledGeneration < 0) throw new IllegalArgumentException("Negative settled generation.");
        return maximumGenerations == 0 ? 0 : Math.addExact(settledGeneration, maximumGenerations);
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double brnLearningRate, TrainingSource source,
                         BrnSupervision supervision, BrnRunSeeds runSeeds) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, brnLearningRate, source, supervision, runSeeds, null);
    }
    public TrainerConfig withTeacherStore(String value) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, supervision, runSeeds, value, maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double brnLearningRate, TrainingSource source, BrnSupervision supervision) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, brnLearningRate, source, supervision, null);
    }
    public TrainerConfig withRunSeeds(BrnRunSeeds value) {
        return new TrainerConfig(checkpointRoot, value == null ? masterSeed : value.masterSeed(), selfPlay, training,
                validation, maximumGenerations, depthChange, startingFen, architecture, brnLearningRate, source, supervision, value, teacherStore, maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }

    /** Null supervision restores the last campaign objective; legacy/fresh absence means WDL. */
    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double brnLearningRate, TrainingSource source) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, brnLearningRate, source, null);
    }
    public TrainerConfig withSupervision(BrnSupervision value) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, source, value, runSeeds, teacherStore, maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }

    /** Null source restores a stored selection; new BRN-2 lineages default to handcrafted generation. */
    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen,
                         TrainingArchitecture architecture, double brnLearningRate) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                architecture, brnLearningRate, null);
    }

    public TrainerConfig withSource(TrainingSource value) {
        return new TrainerConfig(checkpointRoot, masterSeed, selfPlay, training, validation, maximumGenerations,
                depthChange, startingFen, architecture, brnLearningRate, value, supervision, runSeeds, teacherStore, maximumRunMillis, frozenReplayHash, validationMethod, captureConsistency, corpusTraining);
    }

    /** Excludes run duration and fresh-only learning rate; resume restores the exact stored optimizer. */
    public String generationSettings(long generation) {
        return selfPlay(generation) + "|" + training(generation) + "|" + seed(generation, SeedDomain.HOLDOUT) + "|" + startingFen + (runSeeds == null ? "" : runSeeds.settingsSuffix())
                + effectiveCaptureConsistency().settingsSuffix()
                + (effectiveCaptureConsistency().enabled() ? ":seed=" + seed(generation, SeedDomain.CAPTURE) : "")
                + (corpusTraining == null ? "" : corpusTraining.settings())
                + (training.learningRate() == null ? "" : "|learningRate=" + training.learningRate())
                + (frozenReplayHash.isEmpty() ? "" : com.ohinteractive.seedv6.training.checkpoint.FrozenReplay.SETTINGS_PREFIX + frozenReplayHash);
    }

    /** Historical fingerprint before validation became an independent selection. */
    public String legacyAttemptSettings(long generation, TrainingSource selected) {
        return generationSettings(generation) + (selected.bootstrap() ? "" : "|" + validation(generation) + "|" + validation.policy());
    }

    /** Stable campaign values for history grouping; per-generation RNG streams remain in attempts. */
    public String historySettings(TrainingSource selected) {
        return selfPlay + "|" + training + "|source=" + selected + "|validation=" + validationMethod(selected)
                + (heldOut(selected) ? "" : "|" + validation) + "|masterSeed=" + masterSeed
                + "|runSeeds=" + runSeeds + "|supervision=" + (selected.corpus() ? architecture.nnueFamily()
                ? com.ohinteractive.seedv6.training.nnue.NnueCorpusTargets.ID : "CORPUS_CP_BASIC_V1" : supervision == null ? BrnSupervision.WDL : supervision)
                + "|teacher=" + (teacherStore == null ? "" : teacherStore) + "|fen=" + startingFen
                + effectiveCaptureConsistency().settingsSuffix()
                + (corpusTraining == null ? "" : corpusTraining.settings())
                + (frozenReplayHash.isEmpty() ? "" : "|replay=" + frozenReplayHash)
                + brn3SearchCalibrationSuffix();
    }

    public String attemptSettings(long generation, TrainingSource selected) {
        String frozenSuffix = frozenReplayHash.isEmpty() ? ""
                : com.ohinteractive.seedv6.training.checkpoint.FrozenReplay.SETTINGS_PREFIX + frozenReplayHash;
        String generated = generationSettings(generation);
        return generated.substring(0, generated.length() - frozenSuffix.length()) + "|validation=" + validationMethod(selected).name()
                + (heldOut(selected) ? "" : "|" + validation(generation) + "|" + validation.policy())
                + "|supervision=" + (supervision == null ? BrnSupervision.WDL : supervision)
                + "|teacher=" + (teacherStore == null ? "" : teacherStore) + frozenSuffix
                + (heldOut(selected) ? "" : brn3SearchCalibrationSuffix());
    }

    /** Prevent mixing old and calibrated game results in an unfinished BRN-3 attempt. */
    private String brn3SearchCalibrationSuffix() {
        return architecture == TrainingArchitecture.BRN_PAIR2
                ? "|pair2-search=" + com.ohinteractive.seedv6.core.brnpair2.BrnPair2Model.CALIBRATION_ID
                : architecture == TrainingArchitecture.BRN3
                ? "|brn3-search=" + com.ohinteractive.seedv6.core.brn3.Brn3SearchCalibration.ID : "";
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange, String startingFen) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, startingFen,
                TrainingArchitecture.NNUE, DEFAULT_BRN_LEARNING_RATE);
    }

    public TrainerConfig(Path root, long seed, SelfPlay selfPlay, Training training, Validation validation,
                         long maximumGenerations, DepthChange depthChange) {
        this(root, seed, selfPlay, training, validation, maximumGenerations, depthChange, STANDARD_START);
    }

    public record SelfPlay(int depth, int threads, int games, int minimumOpeningPlies, int maximumOpeningPlies,
                           int maximumSamplesPerGame, int maximumPlies, NnueScoreMapping scoreMapping) {
        public SelfPlay {
            new SelfPlayConfig(games, depth, threads, 0, minimumOpeningPlies, maximumOpeningPlies,
                    maximumSamplesPerGame, maximumPlies, scoreMapping, -1, -1);
        }
        SelfPlayConfig at(long seed) {
            return new SelfPlayConfig(games, depth, threads, seed, minimumOpeningPlies, maximumOpeningPlies,
                    maximumSamplesPerGame, maximumPlies, scoreMapping, -1, -1);
        }
    }

    public record Training(int epochs, int minibatchSize, boolean shuffle, Double learningRate) {
        public Training(int epochs, int minibatchSize, boolean shuffle) { this(epochs, minibatchSize, shuffle, null); }
        public Training {
            new SelfPlayTraining.Config(epochs, minibatchSize, shuffle, 0);
            if (learningRate != null) new BrnAdamConfig(learningRate);
        }
        public com.ohinteractive.seedv6.training.model.TrainingRecipe recipe(double storedRate) {
            return new com.ohinteractive.seedv6.training.model.TrainingRecipe(learningRate == null ? storedRate : learningRate, minibatchSize, epochs);
        }
        // Historical generation/history fingerprints must stay byte-identical when no override exists.
        @Override public String toString() {
            return "Training[epochs=" + epochs + ", minibatchSize=" + minibatchSize + ", shuffle=" + shuffle
                    + (learningRate == null ? "" : ", learningRate=" + learningRate) + "]";
        }
        SelfPlayTraining.Config at(long seed) { return new SelfPlayTraining.Config(epochs, minibatchSize, shuffle, seed); }
    }

    public record Validation(int openingPairs, int minimumOpeningPlies, int maximumOpeningPlies, int depth,
                             int threads, int maximumPlies, NnueScoreMapping scoreMapping, PromotionPolicy policy, long moveMillis) {
        public Validation(int pairs, int min, int max, int depth, int threads, int cap, NnueScoreMapping mapping, PromotionPolicy policy) {
            this(pairs, min, max, depth, threads, cap, mapping, policy, 0);
        }
        @Override public String toString() {
            return "Validation[openingPairs=" + openingPairs + ", minimumOpeningPlies=" + minimumOpeningPlies
                    + ", maximumOpeningPlies=" + maximumOpeningPlies + ", depth=" + depth + ", threads=" + threads
                    + ", maximumPlies=" + maximumPlies + ", scoreMapping=" + scoreMapping + ", policy=" + policy
                    + (moveMillis > 0 ? ", moveMillis=" + moveMillis : "") + "]";
        }
        public Validation {
            Objects.requireNonNull(policy);
            new ValidationConfig(openingPairs, 0, minimumOpeningPlies, maximumOpeningPlies,
                    depth, threads, scoreMapping, maximumPlies, moveMillis);
        }
        public String searchDescription() { return moveMillis > 0 ? moveMillis + " ms / move" : "Depth " + depth; }
        ValidationConfig at(long seed) {
            return new ValidationConfig(openingPairs, seed, minimumOpeningPlies, maximumOpeningPlies,
                    depth, threads, scoreMapping, maximumPlies, moveMillis);
        }
    }

    /** Indexed, separate RNG streams; no time, scheduling or previous game length enters identity. */
    public long seed(long generation, SeedDomain domain) {
        if (generation < 0) throw new IllegalArgumentException("Negative generation.");
        long streamSeed = runSeeds != null && domain == SeedDomain.SELF_PLAY ? runSeeds.dataSeed() : masterSeed;
        return new SplittableRandom(streamSeed ^ Objects.requireNonNull(domain).salt
                ^ (generation * 0x9E3779B97F4A7C15L)).nextLong();
    }
    public SelfPlayConfig selfPlay(long generation) { return selfPlay.at(seed(generation, SeedDomain.SELF_PLAY)); }
    public SelfPlayTraining.Config training(long generation) { return training.at(seed(generation, SeedDomain.SHUFFLE)); }
    public ValidationConfig validation(long generation) { return validation.at(seed(generation, SeedDomain.VALIDATION)); }
    public long[] startingBoard() { return Board.fromFen(startingFen); }
}
