package com.ohinteractive.seedv6.rules;

import java.util.Arrays;
import java.util.Objects;

import com.ohinteractive.seedv6.core.Board;
import com.ohinteractive.seedv6.core.util.Value;

/**
 * Search-owned primitive stack containing a game-history snapshot followed by
 * real legal positions on the current searched line. A synthetic pass is not
 * pushed as an occurrence. Its explicit barrier isolates the subsequent local
 * legal segment from pre-pass history, and is removed on probe unwind.
 */
public final class SearchLineHistory {

    public SearchLineHistory(GameHistory gameHistory) {
        this(gameHistory, DEFAULT_LINE_CAPACITY);
    }

    /** Reserve the complete nominal line before traversal, avoiding growth in recursive search. */
    public SearchLineHistory(GameHistory gameHistory, int lineCapacity) {
        Objects.requireNonNull(gameHistory, "gameHistory");
        if(lineCapacity < 0) throw new IllegalArgumentException("Negative line capacity.");
        rootSize = gameHistory.size();
        final long desired = (long) rootSize + lineCapacity;
        final int capacity = desired > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) desired;
        keys = new long[Math.max(rootSize, capacity)];
        gameHistory.copyInto(keys);
        size = rootSize;
        previous = new int[keys.length];
        Arrays.fill(heads, -1);
        for(int i = 0; i < size; i++) link(i);
    }

    public int size() {
        return size;
    }

    /** One isolated speculative subtree; recursive passes are prohibited. */
    public void enterSyntheticPosition(long[] board) {
        if(syntheticStart != -1) throw new IllegalStateException("Nested synthetic history.");
        syntheticStart = size;
        syntheticKey = repetitionKey(board[0], board[1], board[2], board[3],
                (int) board[Board.STATUS], board[Board.KEY]);
    }

    public void leaveSyntheticPosition() {
        if(size != syntheticStart) throw new IllegalStateException("Unbalanced synthetic history.");
        syntheticStart = -1;
    }

    public int rootSize() {
        return rootSize;
    }

    public long currentKey() {
        return keys[size - 1];
    }

    public void pushRealPosition(long[] position) {
        Objects.requireNonNull(position, "position");
        if(position.length < Board.MAX_BITBOARDS) {
            throw new IllegalArgumentException("Board must contain at least " + Board.MAX_BITBOARDS + " longs.");
        }
        pushRealPosition(
            position[0], position[1], position[2], position[3],
            (int) position[Board.STATUS], position[Board.KEY]
        );
    }

    public void pushRealPosition(
        long board0, long board1, long board2, long board3, int status, long boardKey
    ) {
        ensureCapacity(size + 1);
        keys[size] = repetitionKey(board0, board1, board2, board3, status, boardKey);
        link(size++);
    }

    public void popRealPosition() {
        if(size == rootSize) {
            throw new IllegalStateException("Cannot pop the game-history root from a search line.");
        }
        size--;
        heads[bucket(keys[size])] = previous[size];
        keys[size] = 0L;
    }

    /**
     * Restores the immutable game-history prefix after normal or exceptional
     * traversal unwind.
     */
    public void restoreRoot() {
        while(size > rootSize) popRealPosition();
        syntheticStart = -1;
    }

    public int currentOccurrences(long[] currentBoard) {
        Objects.requireNonNull(currentBoard, "currentBoard");
        if(currentBoard.length < Board.MAX_BITBOARDS) {
            throw new IllegalArgumentException("Board must contain at least " + Board.MAX_BITBOARDS + " longs.");
        }
        return currentOccurrences(
            currentBoard[0], currentBoard[1], currentBoard[2], currentBoard[3],
            (int) currentBoard[Board.STATUS], currentBoard[Board.KEY]
        );
    }

    public int currentOccurrences(
        long board0, long board1, long board2, long board3, int status, long boardKey
    ) {
        final long current = repetitionKey(board0, board1, board2, board3, status, boardKey);
        if(size == syntheticStart) {
            if(current != syntheticKey) throw new IllegalArgumentException("Synthetic board mismatch.");
            return 0;
        }
        if(current != currentKey()) {
            throw new IllegalArgumentException("Current board does not match the top search-line position.");
        }
        final int reversiblePlies = Board.halfMoveClock(status);
        final int first = reversiblePlies == Board.MAX_HALF_MOVE_CLOCK
            ? 0
            : Math.max(0, size - 1 - reversiblePlies);
        int count = 0;
        // Earlier equal keys must be in this chain. Full-key comparison handles
        // bucket collisions; decreasing indexes preserve both history barriers.
        for(int i = size - 1; i >= Math.max(first, syntheticStart); i = previous[i]) {
            if(keys[i] == current) count ++;
        }
        return count;
    }

    public boolean isFormalThreefold(long[] currentBoard) {
        return currentOccurrences(currentBoard) >= 3;
    }

    public boolean isFormalThreefold(
        long board0, long board1, long board2, long board3, int status, long boardKey
    ) {
        return currentOccurrences(board0, board1, board2, board3, status, boardKey) >= 3;
    }

    private static final int DEFAULT_LINE_CAPACITY = 64;
    private static final int MAX_MOVES = 256;

    private final int rootSize;
    private final long[] identityMoves = new long[MAX_MOVES];
    private final long[] generatorScratch = new long[Board.MAX_BITBOARDS];
    private long[] keys;
    // A stack of bucket heads needs no deletion/tombstones or per-node allocation.
    // Pop restores the previous head, including across siblings and cancellation.
    private int[] previous;
    private final int[] heads = new int[256];
    private int size;
    private int syntheticStart = -1;
    private long syntheticKey;

    private static int bucket(long key) {
        return (int) (key ^ (key >>> 32)) & 255;
    }

    private void link(int index) {
        int bucket = bucket(keys[index]);
        previous[index] = heads[bucket];
        heads[bucket] = index;
    }

    // Memoize only EP canonicalization; without EP the board key is already canonical.
    // Match every input, not just the hash, so adjudication retains its consistency check.
    private boolean identityCached;
    private long identityBoard0, identityBoard1, identityBoard2, identityBoard3;
    private int identityStatus;
    private long identityBoardKey, identityKey;

    private long repetitionKey(
        long board0, long board1, long board2, long board3, int status, long boardKey
    ) {
        if(Board.enPassantSquare(status) == Value.INVALID) return boardKey;
        if(identityCached && status == identityStatus && boardKey == identityBoardKey
            && board0 == identityBoard0 && board1 == identityBoard1
            && board2 == identityBoard2 && board3 == identityBoard3) return identityKey;
        final long key = PositionIdentity.repetitionKey(
            board0, board1, board2, board3, status, boardKey, identityMoves, generatorScratch
        );
        identityBoard0 = board0;
        identityBoard1 = board1;
        identityBoard2 = board2;
        identityBoard3 = board3;
        identityStatus = status;
        identityBoardKey = boardKey;
        identityKey = key;
        identityCached = true;
        return key;
    }

    private void ensureCapacity(int required) {
        if(required <= keys.length) return;
        if(required < 0) throw new IllegalStateException("Search-line history capacity overflow.");
        final int grown = keys.length <= (Integer.MAX_VALUE >>> 1)
            ? keys.length << 1
            : Integer.MAX_VALUE;
        if(grown < required) throw new IllegalStateException("Search-line history capacity overflow.");
        keys = Arrays.copyOf(keys, grown);
        previous = Arrays.copyOf(previous, grown);
    }
}
